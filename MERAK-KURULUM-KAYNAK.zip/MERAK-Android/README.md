# MERAK — Android uygulaması (v0.1 kaynak proje)

**Dil:** Türkçe · **Sistem:** Android 8.0+ (API 26+) · **Arayüz:** Kotlin / Jetpack Compose

MERAK; günlük kısa okumalar, yazarları keşfetme, kelime dağarcığı, ufak testler,
"Bunu biliyor muydun?" içerikleri ve ruh hâline uygun küçük önerileri bir araya getiren
sade, koyu lacivert-altın tonlarda bir Android uygulamasıdır.

## İçerik

- Kullanıcının hazırladığı **Şenol Güneş'li MERAK kapağı** kullanıldı.
- **38 özgün Türkçe kısa okuma:** Kafka, Dostoyevski, Goethe, Tolstoy, Virginia Woolf,
  Shakespeare, Borges, Yaşar Kemal, Sabahattin Ali, Saramago, Le Guin, Montaigne,
  Oğuz Atay, Mary Shelley, Jane Austen, Zweig, Achebe, Nazım Hikmet ve birçok başka isim;
  ayrıca tarih, bilim, ekonomi, psikoloji, felsefe, öykü.
- **59 kelime**, anlam ve cümle örnekleriyle; günlük üç kelime ve öğrendim işaretleme.
- **24 kısa ilginç bilgi** + ilk okuma paketiyle mini testler.
- Ruh hâli seçimi ve gündelik küçük öneriler; not defteri ve yatma rutini.
- Favoriler/okundu durumu, günlük tamamlanma, notlar yerel saklanır.

## Günlük internet içerikleri (yeni)

- **Yazar listesi sınır değildir.** Keşfet > "Yazar veya konu yaz" alanına istediğin
  yazarı, şairi, filozofu veya konuyu yazabilirsin. Türkçe Vikipedi'de karşılığı olan
  sonuçlar listelenir. Dünya üzerindeki *her* yazarın kaydının olacağı garanti edilmez.
- Her gün internete bağlanınca **farklı bir yazar ve farklı bir konu** için Türkçe Vikipedi
  özetlerini indirir. Günlük seçki aynı gün saklanır; önceki son başarılı indirme çevrimdışı görülebilir.
- Uygulama açıldığında yeni gün kontrolü yapar. Android WorkManager ayrıca günde yaklaşık bir
  kez ağ olduğunda **arka planda yenilemeyi dener**; Android pil koruma politikaları bunu
  geciktirebilir, kesin saat garantisi yoktur.
- "Yenile" butonu elle güncellemeyi yeniden dener.
- İnternetten alınan her metnin altında **Vikipedi bağlantısı ve lisans bilgisi** bulunur.
  Bunlar kitapların tam metni değildir; Vikipedi özetleridir. Edebî metin taklidi veya
  sahte alıntı eklenmez. Telifli kitapların tam metinleri otomatik indirilmez.
- Herhangi bir yapay zekâ API anahtarı veya ücretli üyelik gerekmez.

**Veri ve gizlilik:** İhtiyaç duyulan ağ izinleri `INTERNET` ve `ACCESS_NETWORK_STATE`.
Kişisel ruh hâli kayıtları, günlüğün, okuma/kelime işaretlerin **yalnızca cihazdaki
SharedPreferences** içinde tutulur. Sunucuda kullanıcı hesabı yoktur.

## Android Studio ile APK oluşturma

1. Android Studio'yu Windows bilgisayarına ücretsiz kur.
2. Bu arşivi aç ve **MERAK-Android** klasörünü `Open` ile içe aktar.
3. Android Studio'da Gradle 8.9 ve Android SDK 35 kullanılmasını sağla. Gradle 8.9
   AGP 8.7.x ile uyumludur. İnternet açık olmalı; bağımlılıklar ilk seferde indirilecek.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` dosyasına çıkar.
6. APK'yı telefona atıp Android'in izin adımlarını izleyerek kurabilirsin.

**Önemli:** Bu çalışma ortamında Android SDK, Gradle ve ağ indirmesi yok.
Bu nedenle burada APK derleyip cihazda doğrulama yapamadım; **dosya bir Android
Studio kaynak projesidir, kurulabilir APK değildir.** Kaynağın paketlenmesi tamamlandı,
ancak Android Studio'da ilk derleme ve gerçek cihaz testi yapılması gerekir.

## Geliştirme notları

- `app/src/main/java/com/merak/app/MainActivity.kt`: Mobil arayüz.
- `.../MerakData.kt`: İçerikler, yerel saklama, Vikipedi istemcisi.
- `.../DailySync.kt`: İsteğe bağlı arka plan güncellemesi.
- `app/src/main/assets/content.json`: Çevrimdışı içerik.
- `app/src/main/res/drawable-nodpi/merak_cover.jpg`: Kapak.
- `generate_content.py` ve `add_readings.py`: Başlangıç veri setini yeniden üretme araçları.
  Veri setini yeniden üretmek için önce `generate_content.py`, sonra `add_readings.py` çalıştır.

Psikoloji/ruh hâli bölümü profesyonel değerlendirme veya tedavi sunmaz.
