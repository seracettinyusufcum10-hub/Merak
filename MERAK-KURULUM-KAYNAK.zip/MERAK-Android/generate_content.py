import json
from pathlib import Path
out=Path(__file__).parent/'app/src/main/assets/content.json'
readings=[]
def r(id,category,title,subtitle,minutes,content,q,options,answer,why,word_ids):
    readings.append(dict(id=id,category=category,title=title,subtitle=subtitle,minutes=minutes,paragraphs=[p.strip().replace('\n',' ') for p in content.strip().split('\n\n')],question=q,options=options,answer=answer,explanation=why,wordIds=word_ids))

r('kafka','Edebiyat','Kafka: Bir sabah başka biri olsaydın','Bir hikâyenin insanı neden bu kadar huzursuz ettiğini keşfet.',4,'''
Bir sabah uyandığında herkes sana dün olduğun kişiymişsin gibi davranmayı bıraksaydı ne hissederdin? Franz Kafka'nın eserleri tam da böyle bir huzursuzluğun çevresinde dolaşır. Günlük hayat yerindedir: odalar, işler, aileler, koridorlar… Ama görünmez bir kural değişmiştir ve kimse onu açıklamaya yanaşmaz.

Kafka'nın Dönüşüm adlı eserinde Gregor Samsa bir sabah kendini devasa, böceğimsi bir yaratığa dönüşmüş bulur. Bu tuhaf başlangıç yalnızca fantastik bir olay değildir. Gregor'un aklına gelen ilk meselelerden biri işe yetişmektir. İnsan okurken şaşırır: Böyle olağanüstü bir şeyin ortasında neden işini düşünüyor?

Çünkü Kafka bize sadece bir bedenin değişmesini değil, insanın sorumlulukları altında ezilmesini de düşündürür. Gregor ailesinin geçimini sağlayan kişidir. İşe yaramadığı andan itibaren çevresinin ona bakışı da değişir. Burada okurun önüne rahatsız edici bir soru çıkar: Birini yalnızca bize sağladığı fayda kadar mı severiz?

Kafka'nın dünyasında dev bir canavar olmak zorunda değilsin. Bir iş yerinde sesini duyuramamak, açıklanmayan bir kararla karşılaşmak ya da kendini sürekli suçlu hissetmek de aynı atmosferi yaratabilir. Dava romanındaki Josef K. nedenini tam bilmediği bir suçlamayla karşılaşır. Okuyucu da onun gibi cevabı arar.

Belki Kafka'yı ilginç yapan, her şeyi açıklamamasıdır. Okur eksik kalan parçaları kendi hayatından tamamlar. İyi edebiyat bazen bize bir cevap vermez; uzun süre aklımızda kalan bir soru bırakır.

Şimdi düşün: Senin hayatında, herkesin normal gördüğü ama sana açıklanması gereken bir kural var mı?
''','Dönüşüm eserinde Gregor Samsa’nın ilk kaygılarından biri nedir?',['Bir mahkemeye gitmek','İşe yetişememek','Bir gemiye binmek','Şehirden kaçmak'],1,'Gregor, olağanüstü durumuna rağmen iş sorumluluğunu düşünür. Bu, eserin yarattığı çarpıcı çelişkilerden biridir.',['kaniksamak','yabancilasma','celiski'])

r('dostoyevski','Edebiyat','Dostoyevski: İnsan kendinden kaçabilir mi?','Suç, vicdan ve içimizdeki tartışmalar.',4,'''
Hiç yaptığın küçük bir hatayı aklında defalarca yeniden yaşadığın oldu mu? Bazen olay bitmiştir ama zihnimiz tartışmaya devam eder. Fyodor Dostoyevski'nin karakterleri bu iç konuşmanın çok daha sert biçimleriyle yaşar.

Suç ve Ceza romanının merkezindeki Raskolnikov, korkunç bir eylemden önce kendine akılcı gerekçeler bulmaya çalışır. Bazı insanların toplum için büyük işler yapabilmek adına sıradan kuralları aşabileceği düşüncesine tutunur. Fakat insan düşüncelerini matematik işlemi gibi çözemez. Vicdan, korku, gurur ve merhamet birbirine karışır.

Romanı yalnızca bir suç hikâyesi gibi okumak eksik kalır. Asıl gerilim, karakterin zihninde yaşanır. Dışarıdaki şehir kalabalıktır, odalar dardır, ilişkiler gergindir. Raskolnikov ne kadar kendi kurduğu açıklamalara sığınsa da yaptığının ağırlığından bütünüyle kurtulamaz.

Dostoyevski'nin gücü, karakterlerini sadece iyi veya kötü olarak çizmemesinde. Bir insan hem kibirli hem kırılgan, hem fedakâr hem bencil olabilir. Farklı duyguların aynı kişide bulunması onu daha gerçek kılar.

Buradan gündelik hayatımıza dönebiliriz. Bir tartışmada haklı olmayı mı, gerçekten anlamayı mı istiyoruz? Bir davranışımız için güzel bir açıklama bulmak, o davranışı doğru yapar mı? Kendi kendimize verdiğimiz cevaplarla başkalarına gösterdiğimiz yüz her zaman aynı olmayabilir.

İyi bir hikâye bazen kahramanı yargılamaktan çok, kendimizi sorgulamamıza yol açar.
''','Suç ve Ceza’nın merkezindeki karakter kimdir?',['Gregor Samsa','Raskolnikov','Josef K.','Meursault'],1,'Raskolnikov, Suç ve Ceza romanının merkezindeki karakterdir.',['vicdan','gerekce','merhamet'])

r('goethe','Edebiyat','Goethe: Bir insan neden hep daha fazlasını ister?','Faust üzerinden arzu, bilgi ve tatmin.',4,'''
Bir hedefe ulaştıktan sonra hemen yeni bir hedef düşündüğün oldu mu? Daha iyi bir telefon, daha yüksek bir not, daha güçlü bir beden… İnsan bazen istediğine kavuştuğunda bile içindeki boşluk tamamen dolmaz. Johann Wolfgang von Goethe'nin Faust adlı eseri bu bitmeyen arayışı düşündürür.

Faust çok şey öğrenmiş bir bilgedir. Fakat kitaplar ve akademik başarı ona beklediği huzuru vermez. Hayatın bütün anlamına yaklaşmak ister. Bu istek, eserin temel gerilimlerinden birini yaratır: Bilmek ile gerçekten yaşamak aynı şey midir?

Goethe'nin eserinde Mefistofeles önemli bir figürdür. Faust'un arzuları ve seçimleri üzerinden insanın sınırları tartışmaya açılır. Hikâye yalnızca iyi ile kötünün mücadelesi değildir; insanın tatminsizliği, merakı ve yaptığı tercihlerin sonuçları da önemlidir.

Burada küçük bir ayrım var: Merak etmek kötü değildir. Hatta yeni şeyler öğrenmek için gereklidir. Sorun, merakı hiçbir şeyin yeterli gelmediği bir yarışa dönüştürmek olabilir. Her yeni başarının hemen değersizleştiği bir hayat yorucudur.

Bir gün içinde öğrendiğin tek bir şeyi gerçekten anlamak, yüz başlığı hızla geçmekten daha değerli olabilir. MERAK uygulamasının da amacı yalnızca bilgi sayısını artırmak değil; üzerinde düşündüğün küçük fikirler biriktirmek.

Bugün bir şeyi sadece merak ettiğin için öğrensen, bu ne olurdu?
''','Faust karakterinin temel sıkıntılarından biri hangisidir?',['Bildiği şeylere rağmen tatmin olamaması','Tarih kitaplarından nefret etmesi','Bir ülkeyi yönetmek istemesi','Bir yarış kazanamaması'],0,'Faust, geniş bilgisine karşın hayatın anlamı ve doyum konusunda huzursuzdur.',['tatmin','muhakeme','arayis'])

r('orwell','Edebiyat','Orwell: Herkes izleniyorsa ne olur?','1984, dil ve düşüncenin sınırları.',4,'''
Bir odada yalnız olduğunu düşün. Sonra duvarın seni izlediğini öğren. Davranışların değişir mi? George Orwell'in 1984 romanı, gözetimin sadece hareketleri değil düşünme biçimini de nasıl etkileyebileceğini anlatır.

Romanda Büyük Birader, iktidarın her yerde hissedilen simgesidir. İnsanların davranışları denetlenirken dil de dönüştürülür. Yeni Söylem adı verilen tasarlanmış dil, ifade edilebilecek düşünceleri daraltmayı amaçlar. Böylece sözcükler üzerine kurulan mücadelenin yalnızca dil bilgisiyle ilgili olmadığını görürüz.

Bir duyguyu anlatacak sözcüğün olmadığını düşün. Yanlış giden bir şeyi nasıl tarif edersin? Kelimeler düşüncelerimizi tek başına belirlemez ama daha hassas ifade etmemize yardım eder. İşte kelime haznesi geliştirmek yalnızca güzel konuşmak değildir: Karmaşık durumları daha açık tanımak demektir.

1984 bir kurmaca eserdir. Onu okurken romandaki dünyayı bugünün tek ve eksiksiz açıklaması olarak almak gerekmez. Daha iyi sorular sormak için kullanabiliriz: Kim hangi bilgiyi topluyor? Bilgiye nasıl erişiyoruz? Kimin sözcüklerini tekrar ediyoruz?

Bir kelime öğrendiğinde yalnızca sözlüğünü genişletmezsin. Bazen daha önce fark ettiğin ama adını koyamadığın bir durumu tarif edebilir hâle gelirsin.
''','1984 romanında düşünceyi sınırlandırmak için tasarlanan dilin adı nedir?',['Yeni Söylem','Eski Türkçe','Latince','Ortak Dil'],0,'Yeni Söylem, romandaki iktidarın düşünce ve ifade alanını daraltma tasarımının parçasıdır.',['gözetim','ifade','manipulasyon'])

r('saitfaik','Edebiyat','Sait Faik: Sıradan bir insanın hikâyesi','Büyük olay olmadan da edebiyat olur mu?',3,'''
Bazı hikâyelerde savaşlar, saraylar veya dünyayı değiştiren kararlar vardır. Sait Faik Abasıyanık ise çoğu zaman dikkatimizi bambaşka bir yere çeker: Balıkçılara, sokaklara, kahvelere, kıyılara ve sıradan insanların kısa karşılaşmalarına.

Bir vapur beklerken gördüğün yaşlı bir adamı düşün. Senin için kalabalığın içindeki yüzlerden biridir. Oysa o insanın da sevinçleri, korkuları, geçmişi ve kimseye anlatmadığı düşünceleri vardır. Edebiyat bazen bize bu görünmez hayatları fark ettirir.

Sait Faik'in öykülerinde insanlara yaklaşan sıcak bir merak hissedilir. Karakterler her zaman büyük kararlar almaz; bazen yürür, konuşur veya susarlar. Ama metindeki küçük ayrıntılar sayesinde okuyucu başka bir insanın dünyasına girer.

Bunun günlük hayatta karşılığı basittir. Toplu taşımada, sahada, okulda veya sokakta gördüğümüz herkesi tek bir etikete sığdırmak kolaydır. Oysa insanları anlamak için biraz dikkat ve biraz da önyargımızı askıya almak gerekir.

Bugün çevrende sıradan görünen bir ayrıntıyı fark etmeyi dene: Bir dükkânın ışığı, yağmurun sesi, birinin beklerken yaptığı hareket. İyi gözlem, hem yazmanın hem düşünmenin başlangıcı olabilir.
''','Sait Faik’in öykülerinde sık karşılaşılan konu hangisidir?',['Yalnızca kralların savaşları','Gündelik insanların yaşamı','Uzay gemileri','Tarihî hanedan listeleri'],1,'Sait Faik, sıradan insanların hayatlarına ve günlük hayattaki ayrıntılara özel ilgi gösterir.',['gozlem','onyargi','ayrinti'])

r('camus','Felsefe','Camus: Hayatın anlamı hazır mı gelir?','Saçma kavramına basit bir giriş.',4,'''
İnsan bazen bir şeyin neden olduğunu anlamak ister. Başarısız olduğu gün, kaybettiği arkadaşlıkta, beklediği cevabı alamadığında… Peki ya dünya her sorumuza net bir karşılık vermiyorsa?

Albert Camus, insanın anlam arayışı ile dünyanın buna her zaman açık bir yanıt vermemesi arasındaki gerilimi “saçma” kavramıyla ele alır. Buradaki saçma, yalnızca komik ya da mantıksız demek değildir. İnsan sorar, dünya çoğu zaman susar. Arada bir uyumsuzluk oluşur.

Camus'nün Sisifos Söyleni'nde antik bir anlatı karşımıza çıkar. Sisifos bir kayayı tepeye taşımaya mahkûmdur; kaya her seferinde geri yuvarlanır. Aynı işi yeniden yapmak neden insanı düşündürür? Çünkü tekrara ve sınırlarına rağmen yaşamla kurduğumuz ilişkiyi sorgularız.

Camus'nün yaklaşımını “Her şey anlamsızdır, hiçbir şey yapma” diye özetlemek yanlış olur. O, karşılaştığımız durumla yüzleşmenin ve yaşamı bilinçle sürdürmenin önemini tartışır.

Gündelik bir örnek düşün: Bütün hayatını tek bir büyük amaca bağlamak zorunda değilsin. Bir arkadaşına yardım etmek, bir beceriyi geliştirmek veya bir soruyu araştırmak da anlamlı deneyimler olabilir. Bazen hayatın tek bir hazır cevabı olmadığını kabul etmek, daha özgür sorular sormamızı sağlar.
''','Camus’de “saçma” kavramı neyi ifade eder?',['Yalnızca güldürücü olayları','İnsanın anlam arayışıyla dünyanın sessizliği arasındaki gerilimi','Matematikteki işlemleri','İnsanın hiçbir şey öğrenemeyeceğini'],1,'Camus, insanın anlam talebiyle dünyanın buna her zaman yanıt vermemesi arasındaki gerilimi tartışır.',['absurt','anlam','bilinc'])

r('stoacilik','Felsefe','Kontrol edebildiğin ve edemediğin şeyler','Stoacılık neden hâlâ konuşuluyor?',3,'''
Bir sınava hazırlanıyorsun. Çalışıp çalışmamak büyük ölçüde senin elinde. Ama soruların tam olarak nasıl geleceğini ve sınav salonundaki her koşulu kontrol edemezsin. Stoacı düşünce, bu iki alanı ayırmanın önemini vurgular.

Epiktetos gibi Stoacı filozoflar, kendi yargılarımız ve tercihlerimizle dış dünyadaki olaylar arasında fark gözetir. Bu, olayların sonuçlarına hiç önem vermemek anlamına gelmez. Yalnızca bütün gücümüzü değiştiremeyeceğimiz şeylerle kavga ederek tüketmemeyi önerir.

Örneğin bir arkadaşının seni yanlış anlamasını tamamen engelleyemezsin. Ama açık konuşmayı, dinlemeyi ve gerektiğinde özür dilemeyi seçebilirsin. Bir maçta rakibin bütün hareketlerini belirleyemezsin; hazırlığını ve verdiğin tepkiyi etkileyebilirsin.

Stoacılık duygusuz olmak değildir. Üzülmek, heyecanlanmak veya kaygılanmak insan deneyiminin parçasıdır. Asıl mesele, duygularımızın içindeyken ne yapacağımızı düşünmektir.

Küçük bir deneme: Bugün seni meşgul eden bir konuyu iki sütuna ayır. Birinde etkileyebileceğin adımlar olsun. Ötekinde yalnızca bekleyebileceğin veya kabul etmek zorunda olduğun koşullar. İlk sütundan tek bir küçük adım seç.
''','Stoacı düşüncede hangisine odaklanmak daha işlevseldir?',['Başkalarının bütün kararlarına','Kendi seçim ve tepkilerine','Havanın her zaman iyi olmasına','Geçmişteki tüm olayları değiştirmeye'],1,'Stoacılık, kişinin kendi yargılarına ve eylemlerine odaklanmasını vurgular.',['irade','tepkı','kabullenme'])

r('felsefesoru','Felsefe','Soru sormak neden cesaret ister?','Sokrates ile düşünmenin başlangıcı.',3,'''
Herkesin aynı cevabı verdiği bir ortamda “Neden?” demek bazen zor gelir. İnsan yanlış anlaşılmaktan veya bilmediğinin ortaya çıkmasından çekinebilir. Oysa iyi bir soru, bilgili görünmekten daha faydalı olabilir.

Sokrates ile ilişkilendirilen sorgulama geleneği, bir iddianın arkasındaki nedenleri araştırır. Örneğin “Başarılı insan kimdir?” sorusunu düşün. Çok para kazanan mı? Güvenilir olan mı? Hedeflerine ulaşan mı? Verdiğin her cevap yeni bir soru doğurur.

Bu tarz konuşmanın amacı herkesi yenmek değildir. Kullandığımız kavramları daha açık hâle getirmektir. Bazen bir kelimeye verdiğimiz anlam, tartışmanın neden bitmediğini açıklar. İki kişi aynı sözcüğü kullanır ama farklı şeyler düşünür.

Sorgulamak her iddiayı otomatik olarak yanlış kabul etmek de değildir. Delile bakmak, karşı görüşü anlamak, emin olmadığımız yerde “Bilmiyorum” diyebilmek gerekir. Fikir değiştirmek bir yenilgi değil, yeni bilgiye verilen mantıklı bir yanıt olabilir.

Bugün duyduğun kesin bir yargıyı seç ve kendine sor: “Bunu nereden biliyorum? Hangi kanıt fikrimi değiştirebilir?” Merak bazen iyi bir cevapla değil, daha iyi bir soruyla başlar.
''','Sokrates ile ilişkilendirilen sorgulamanın temel amacı nedir?',['Her tartışmayı kazanmak','Kavram ve gerekçeleri araştırmak','Soruları tamamen yasaklamak','Sadece ezber yapmak'],1,'Sokratik sorgulama, iddiaların tanımlarını ve gerekçelerini araştırır.',['sorgulama','kanit','varsayim'])

r('roma','Tarih','Roma neden tek bir günde yıkılmadı?','Bir imparatorluğun uzun değişim hikâyesi.',4,'''
“Roma İmparatorluğu neden yıkıldı?” sorusu tek cümlelik bir cevap ister gibi görünür. Oysa yüzyıllarca yaşamış büyük bir siyasi yapının dönüşümünü anlamak için birçok etkene birlikte bakmak gerekir.

Roma İmparatorluğu zaman içinde çok geniş topraklara yayıldı. Bu genişliği yönetmek, sınırları korumak ve orduları finanse etmek ciddi kaynak gerektiriyordu. Ekonomik baskılar, iç siyasi mücadeleler ve sınır bölgelerindeki çatışmalar zaman zaman birbirini güçlendirdi.

395 yılında imparatorluğun doğu ve batı bölümleri ayrı yönetim çizgilerine geçti. 476 yılı, Batı Roma'da son imparator Romulus Augustulus'un tahttan indirilmesi nedeniyle geleneksel bir dönüm noktası kabul edilir. Fakat Doğu Roma, yani Bizans İmparatorluğu, İstanbul merkezli olarak 1453'e kadar varlığını sürdürdü.

Bu nedenle “Roma 476'da tamamen yok oldu” demek tarihî süreci fazla basitleştirir. Kurumlar, kültürler, diller ve hukuk gelenekleri bir anda ortadan kaybolmadı. Roma mirası farklı toplumlarda değişerek yaşamaya devam etti.

Tarihten çıkarılacak önemli bir ders var: Büyük olayların çoğu tek bir sebebe dayanmaz. Bir maçın kaybını yalnızca son dakikadaki bir hatayla açıklayamayacağımız gibi, bir imparatorluğun değişimini de tek güne sığdıramayız.
''','476 yılı genellikle hangi olayla ilişkilendirilir?',['Doğu Roma’nın kuruluşuyla','Batı Roma’daki son imparatorun tahttan indirilmesiyle','İstanbul’un fethiyle','Fransız Devrimi’yle'],1,'476, Batı Roma imparatoru Romulus Augustulus’un tahttan indirilmesiyle ilişkilendirilir.',['imparatorluk','miras','donum'])

r('matbaa','Tarih','Bir makine fikirleri nasıl hızlandırdı?','Matbaa, kitaplar ve bilgiye erişim.',3,'''
Bir kitabın tek kopyasının hazırlanması günler veya haftalar sürebilseydi, onu kaç kişi okuyabilirdi? Tarih boyunca metinlerin elle çoğaltılması emek ve zaman gerektiriyordu. Baskı tekniklerinin yayılması bu sınırları önemli ölçüde değiştirdi.

Matbaa tek bir kişinin bir anda icat ettiği basit bir araç değildir. Doğu Asya'da çok daha erken dönemlerden itibaren baskı teknikleri kullanıldı. Avrupa'da Johannes Gutenberg'in 15. yüzyılda geliştirdiği hareketli metal harflerle baskı sistemi ise kitap üretiminin ölçeği üzerinde büyük bir etki yarattı.

Kitapların daha geniş çevrelere ulaşabilmesi, dinî, bilimsel ve siyasi düşüncelerin dolaşımını hızlandırdı. Yine de herkes hemen okuyabilir hâle gelmedi. Okuryazarlık, dil, ekonomik koşullar ve sansür gibi etkenler bilgiye erişimi biçimlendirmeye devam etti.

Bugün bir bilgiye telefondan birkaç saniyede ulaşıyoruz. Bu büyük bir imkân ama yeni bir soru doğuruyor: Erişmek ile anlamak aynı şey mi? Bir başlığı görmek, konuyu öğrenmiş olmak anlamına gelmez. Bazen kısa bir metin üzerinde düşünmek, onlarca bağlantı arasında kaybolmaktan iyidir.

Bilginin hızlandığı bir çağda asıl beceri, hangi bilgiyi seçtiğimiz ve onu nasıl değerlendirdiğimiz olabilir.
''','Gutenberg’in Avrupa’da geliştirdiği baskı sistemi hangi yüzyılla ilişkilidir?',['11. yüzyıl','13. yüzyıl','15. yüzyıl','19. yüzyıl'],2,'Gutenberg’in hareketli metal harflerle baskı sistemi 15. yüzyılda yaygınlaşmaya başladı.',['erisim','yayilim','kaynak'])

r('haritalar','Coğrafya','Dünya haritası neden gerçeğin aynısı değil?','Küreyi düz bir kâğıda sığdırmanın bedeli.',3,'''
Telefonundaki dünya haritasını aç ve Grönland'a bak. İlk bakışta Afrika'yla benzer büyüklükte görünebilir. Oysa Afrika'nın yüz ölçümü Grönland'ınkinden yaklaşık 14 kat fazladır. Bu farkın önemli nedeni harita projeksiyonudur.

Dünya'ya yaklaşık küresel bir yüzey olarak bakabiliriz. Küresel bir yüzeyi düz bir kâğıda aktarmaya çalıştığında en az bir özelliği bozarsın: alan, şekil, uzaklık veya yön. Her projeksiyon farklı bir öncelik seçer.

Mercator projeksiyonu denizcilikte yön koruma açısından faydalı özelliklere sahiptir. Fakat yüksek enlemlerdeki bölgeleri olduğundan büyük gösterir. Bu yüzden bir ülkenin haritadaki görüntüsünü gerçek yüz ölçümüyle karıştırmamak gerekir.

Haritalar bize başka bir düşünme alışkanlığı da kazandırır. Her gösterim bir seçim yapar. Grafiklerde hangi ölçeğin kullanıldığı, haberlerde hangi tarihin karşılaştırıldığı veya bir fotoğrafın nereden çekildiği de algımızı etkiler.

Bir görsel çok ikna edici göründüğünde kendine şu soruyu sor: “Bu gösterim neyi iyi anlatıyor, neyi gizliyor?” Merak sadece yeni bilgi almak değil, bilginin nasıl sunulduğunu görmek demektir.
''','Mercator haritasında yüksek enlemlerdeki bölgeler genellikle nasıl görünür?',['Gerçek alanlarından daha büyük','Tamamen kaybolmuş','Gerçek alanlarından daha küçük','Bütünüyle ters yönde'],0,'Mercator projeksiyonu yüksek enlemlerde alanları büyütür.',['projeksiyon','olcek','algı'])

r('beyin','Bilim','Beynin neden bazen seni yanıltır?','Görmek, hatırlamak ve tahmin etmek.',4,'''
Kalabalık bir odada biri adını söylediğinde hemen fark edebilirsin. Aynı ortamda başka birçok ses vardır ama hepsini eşit derecede işlemezsin. Dikkat, beynin sınırlı kaynaklarını belirli bilgilere yöneltmesine yardım eder.

Görmek de dış dünyayı kusursuz bir kamera gibi kaydetmek değildir. Beynimiz duyusal bilgileri daha önceki deneyimlerimizle birlikte yorumlar. Görsel yanılsamalar bu nedenle ilginçtir: Aynı çizgi veya renk, çevresindeki desenlere göre farklı algılanabilir.

Hafıza da birebir video kaydı gibi çalışmaz. Olayları hatırlarken bilgileri yeniden kurabiliriz. Bu yüzden iki kişinin aynı anı farklı ayrıntılarla anlatması mutlaka birinin yalan söylediğini göstermez. Dikkat, beklentiler ve geçen zaman anlatımı etkileyebilir.

Bu bilgiler insanın hiçbir şeye güvenemeyeceği anlamına gelmez. Tam tersine, önemli konularda not almak, farklı kaynakları kontrol etmek ve bir iddiayı yeniden sınamak için iyi nedenler sunar.

Yeni bir kelimeyi kalıcı öğrenmek için onu yalnızca okumak yerine kendi cümlenle kullanmayı dene. Bir bilgiyi hatırlamaya çalışmak, tekrar okuyup geçmekten farklı bir zihinsel çaba ister.
''','Hafıza ile ilgili hangi ifade daha doğrudur?',['Her anıyı birebir saklar','Hatırlama sırasında ayrıntılar yeniden kurulabilir','Zamanla hiç değişmez','Sadece görüntü depolar'],1,'Hafıza yeniden yapılandırıcı süreçler içerir; hatırlanan ayrıntılar etkilenebilir.',['algı','yanilsama','hafiza'])

r('ahtapot','Bilim','Ahtapotun üç kalbi var, peki neden?','Denizlerin sıra dışı canlılarından biri.',3,'''
Ahtapotlar sekiz kola sahip olmalarıyla ünlüdür ama vücutları başka şaşırtıcı özellikler de taşır. Çoğu ahtapot türünün üç kalbi vardır. Bunların ikisi kanı solungaçlara gönderirken üçüncüsü oksijenlenmiş kanın vücuda pompalanmasında rol alır.

Ahtapotların kanında oksijen taşınmasına yardımcı olan hemosiyanin adlı, bakır içeren bir molekül bulunur. Bu özellik kanlarına mavimsi bir renk verir. İnsan kanındaki hemoglobin ise demir içerir. Farklı canlıların benzer sorunlara farklı biyolojik çözümler geliştirebilmesi evrimin ilginç örneklerindendir.

Ahtapotlar aynı zamanda karmaşık davranışlar sergileyebilir. Bazı türler kapakları açabilir, bulmacaları çözebilir ve çevrelerindeki nesneleri araştırabilir. Ancak bu davranışları insan zekâsıyla birebir eşitlemek doğru olmaz; farklı çevrelerde gelişmiş farklı becerilerdir.

Bir canlı hakkında tek bir şaşırtıcı bilgi öğrendiğinde konu kapanmaz. Yeni sorular çıkar: Deniz canlılarında oksijen nasıl taşınır? Kalp ve solungaçlar nasıl birlikte çalışır? Başka hangi hayvanlarda sıra dışı dolaşım sistemleri vardır?

Bilimin güzel tarafı budur: İyi bir cevap çoğu zaman yeni bir soruya açılır.
''','Ahtapotun iki kalbi özellikle hangi organa kan gönderir?',['Solungaçlara','Gözlere','Deriye','Mideye'],0,'İki kalp solungaç dolaşımına, bir kalp ise vücut dolaşımına hizmet eder.',['hemosiyanin','dolasim','evrim'])

r('yildiz','Bilim','Gökyüzüne baktığında geçmişi görüyorsun','Işık, uzaklık ve zaman.',3,'''
Gece gökyüzünde bir yıldız gördüğünde, onun ışığı gözlerine ulaşmadan önce çok uzun bir yolculuk yapmış olabilir. Işık çok hızlıdır ama hızı sonsuz değildir. Boşlukta saniyede yaklaşık 300 bin kilometre yol alır.

Güneş ışığının Dünya'ya ulaşması yaklaşık sekiz dakika sürer. Yani Güneş'e baktığında gördüğün görüntü, aslında sekiz dakika önce yola çıkan ışıkla oluşur. Güneş'e doğrudan bakmak gözler için zararlıdır; bu örneği yalnızca zaman kavramı için düşün.

Daha uzaktaki yıldızlarda bu gecikme çok daha büyüktür. Bir yıldız yüzlerce ışık yılı uzaktaysa bugün gördüğün ışık, yüzlerce yıl önce oradan ayrılmış demektir. Işık yılı zaman değil, ışığın bir yılda katettiği uzaklıktır.

Astronomlar uzak gök cisimlerini gözlemleyerek evrenin geçmiş dönemleri hakkında bilgi edinir. Güçlü teleskoplar yalnızca uzaktaki nesneleri daha ayrıntılı görmek için değil, çok eski ışığı incelemek için de önemlidir.

Bir sonraki yıldızlı gecede şunu hatırla: Gökyüzü yalnızca mekân değil, aynı zamanda zaman hakkında bir pencere.
''','Işık yılı neyin birimidir?',['Sıcaklığın','Uzaklığın','Kütlenin','Parlaklığın'],1,'Işık yılı, ışığın bir yılda aldığı yolu ifade eden uzaklık birimidir.',['mesafe','gozlem','astronomi'])

r('erteleme','Psikoloji','Ertelemek neden bu kadar kolay?','Motivasyon gelmeden başlamak mümkün mü?',4,'''
Yapman gereken bir iş var. Beş dakika sonra başlamaya karar veriyorsun. Sonra bir video daha, bir mesaj daha, bir bakış daha… Akşam olduğunda iş hâlâ yerinde. Bu durum her zaman tembellik veya karakter zayıflığı anlamına gelmez.

Erteleme çoğu zaman o anki rahatsızlıktan uzaklaşmakla ilişkilidir. Zor, belirsiz veya sıkıcı bir iş kısa vadede olumsuz duygular yaratabilir. Telefonu kontrol etmekse hemen küçük bir rahatlama sağlar. Fakat sorun çözülmediği için daha sonra yeni bir baskı hissedilebilir.

Çözüm her zaman çok güçlü bir motivasyon beklemek değildir. İşin girişindeki sürtünmeyi azaltmak daha etkili olabilir. “Bir saat ders çalışacağım” yerine “Kitabı açıp iki paragraf okuyacağım” demek başlangıcı kolaylaştırır. Başladıktan sonra devam edip etmemeye karar verebilirsin.

Bir diğer yöntem, ne zaman ve nerede başlayacağını önceden seçmektir. “Yarın spor yapacağım” genel bir niyettir. “Yarın kahvaltıdan sonra ayakkabımı giyip on dakika yürüyeceğim” daha somut bir plandır.

Bazen küçük adımların küçüklüğü seni rahatsız edebilir. Ama amaç ilk gün büyük bir sonuç almak değil, tekrar edebileceğin davranışın kapısını açmaktır. Bir gün aksarsa bütün düzenin bittiğini düşünmene gerek yok. Sonraki uygun anda devam etmek de becerinin parçasıdır.
''','Başlamakta zorlanan biri için en somut ilk adım hangisidir?',['Motivasyon gelene kadar beklemek','İşi iki dakikalık bir parçaya bölmek','Her işi aynı güne toplamak','Hiç ara vermemeye söz vermek'],1,'Çok küçük ve belirli bir ilk adım başlama engelini azaltabilir.',['surtunme','istikrar','erteleme'])

r('ozsaygi','Psikoloji','Kendine saygı küçük sözlerle başlar','Büyük sloganlar yerine güvenilir davranışlar.',3,'''
Kendine verdiğin bir sözü yerine getirdiğinde ne hissedersin? Bu söz büyük olmak zorunda değildir. Sabah yatağını toplamak, yürüyüşe çıkmak ya da bir arkadaşına söz verdiğin saatte yazmak bile kendi davranışını ciddiye almanın bir yolu olabilir.

Özgüven ve özsaygı aynı şey değildir. Özgüven çoğunlukla belli bir işi yapabilme kapasitemize ilişkin inançlarımızla ilişkilidir. Özsaygı ise kendimize yönelik genel değerlendirmemizi ve değer duygumuzu içerir. İkisi etkileşebilir ama birbirinin yerine kullanılması her zaman doğru olmaz.

Kendine saygı kazanmak için her gün kusursuz olmak gerekmez. Aksine, gerçekçi hedefler seçmek daha sürdürülebilirdir. Her gece üç saat okumaya söz verip yapamamak yerine her gün beş dakika okuyup zamanla artırmak daha güvenilir bir başlangıç olabilir.

Kendi kendinle konuşma biçimin de önem taşır. “Bugün yine hiçbir şey yapamadım” demek yerine, “Bugün planladığım işi yapmadım; yarın başlangıcı iki dakikaya indireceğim” daha somut ve eyleme yöneliktir. Bu, hatayı inkâr etmek değil, bir sonraki adımı tarif etmektir.

Bugün kendine yerine getirebileceğin tek bir küçük söz ver. Sözün ölçülü olsun. Akşam geldiğinde sonuca bak, gerekiyorsa planı düzelt. Kendini tanımak, kendine yaklaşımını da değiştirebilir.
''','Aşağıdakilerden hangisi uygulanabilir bir başlangıç hedefidir?',['Her gün kusursuz olmak','Bir günde tüm alışkanlıkları değiştirmek','Her gün beş dakika okumak','Bir kez aksayınca tamamen bırakmak'],2,'Ölçülü ve tekrar edilebilir hedefler alışkanlık kurmayı kolaylaştırabilir.',['ozsaygi','ozguven','sureklilik'])

r('uyku','Psikoloji','Gece neden bir türlü telefonu bırakamıyoruz?','Dinlenmenin ilk adımı mükemmel bir rutin değil.',3,'''
Saat geç olmuş. Sabah erken kalkman gerekiyor ama telefonu bırakınca sanki günün kendine ayırdığın bölümü bitecek. Bir video açıyorsun, ardından bir başkası. Uykun gelse bile ekran başında kalabiliyorsun.

Bu davranışın tek bir nedeni yoktur. Gün içindeki stres, alışkanlıklar, dikkat çekici içerikler ve uyku düzeni birlikte rol oynayabilir. Uykuyu yalnızca irade meselesi gibi görmek çoğu zaman sorunu açıklamaz.

Başlangıç için bütün hayatını bir gecede değiştirmeye çalışma. Telefonu yastığından biraz uzağa koymak, yatmadan önce parlak ekran kullanımını azaltmak ve ertesi gün için tek cümlelik bir plan yazmak gibi küçük adımlar deneyebilirsin.

Düzenli uyuma ve uyanma saatleri, sabah gün ışığına çıkmak ve akşamları sakin bir geçiş oluşturmak birçok kişi için yararlı temel alışkanlıklardır. Ama sürekli uyku sorunu yaşıyorsan yalnızca uygulama önerileriyle yetinmeyip bir sağlık uzmanıyla görüşmek uygun olabilir.

Kendine şu soruyu sor: Bu gece telefonla geçirdiğim son on dakikayı neyle değiştirebilirim? İki sayfa okumak, hafif müzik dinlemek veya yarının ilk işini not etmek gibi küçük bir geçiş, başlamanın bir yolu olabilir.
''','Yatma saatini düzenlemeye başlamak için hangisi daha somut bir adımdır?',['Bütün alışkanlıkları aynı gece değiştirmek','Telefonu yatağın biraz uzağına koymak','Uykuyu tamamen ertelemek','Her gece rastgele saatte yatmak'],1,'Telefonu erişimi daha zor bir yere koymak yatmadan önceki otomatik kullanım alışkanlığını azaltmaya yardımcı olabilir.',['rutin','dinlenme','tutarlilik'])

r('enflasyon','Ekonomi','Enflasyon neden yalnızca fiyat etiketi değildir?','Alım gücü ve günlük hayat.',3,'''
Geçen yıl aynı parayla aldığın ürünleri bugün daha pahalıya alıyorsan, muhtemelen fiyat artışlarını doğrudan hissediyorsun. Ekonomide enflasyon, tek bir ürünün fiyatındaki değişimden farklı olarak, genel fiyat düzeyinin zaman içinde artmasıdır.

Örneğin sadece domatesin fiyatının yükselmesi, tek başına genel enflasyonun kanıtı değildir. Farklı mal ve hizmetlerden oluşan geniş bir sepetin fiyat değişimlerine bakmak gerekir. Ülkeler bu tür değişimleri ölçmek için fiyat endeksleri kullanır.

Enflasyonun günlük hayattaki önemli etkilerinden biri alım gücüdür. Gelirin aynı kalırken genel fiyatlar yükseliyorsa aynı miktarda parayla daha az ürün ve hizmet satın alabilirsin. Maaşının artması bile her zaman satın alma gücünün arttığı anlamına gelmez; fiyatlarla birlikte değerlendirilmelidir.

Bir başka önemli ayrım: Enflasyonun düşmesi, fiyatların mutlaka eski düzeyine dönmesi demek değildir. Fiyatlar hâlâ artıyor olabilir; yalnızca artış hızları yavaşlamıştır. Fiyatların genel olarak düşmesine ise deflasyon denir.

Bu ayrımı öğrendiğinde haberlerdeki ekonomik açıklamaları daha dikkatli yorumlayabilirsin. Bir rakama bakmadan önce “Neyin değişim oranı?” diye sormak çoğu zaman iyi bir başlangıçtır.
''','Enflasyonun düşmesi genellikle ne anlama gelir?',['Bütün fiyatlar eski seviyesine döner','Genel fiyat artışının hızı yavaşlar','Tüm ürünler bedava olur','Para birimi değişir'],1,'Enflasyon oranındaki düşüş, fiyat seviyesinin değil artış hızının azalması anlamına gelebilir.',['enflasyon','alim_gucu','deflasyon'])

r('faiz','Ekonomi','Bileşik etki: Küçük farklar neden büyür?','Para biriktirmekten öğrenme alışkanlığına.',3,'''
Her gün beş sayfa okusan bir yılda ne kadar okumuş olursun? Günlük hedef küçük görünür ama tekrarlandığında birikir. Ekonomide benzer bir birikme mantığını bileşik getiri kavramında görebiliriz.

Basit bir örnek düşün: 100 liranın yıl sonunda yüzde 10 getiriyle 110 liraya ulaştığını varsayalım. Getiriyi içeride bırakırsan ve ertesi yıl yine yüzde 10 getiri olursa sonuç 121 lira olur. İkinci yılda getiri sadece ilk 100 lira üzerinden değil, önceki getirinin de dahil olduğu 110 lira üzerinden hesaplanmıştır.

Gerçek dünyada getiriler sabit veya garantili değildir. Vergiler, ücretler, enflasyon ve riskler sonucu değiştirebilir. Örneğimizin amacı yatırım önerisi vermek değil, bileşik hesaplamanın mantığını göstermek.

Öğrenmede de benzer bir sezgi kullanabiliriz; ama insan zihni bir banka hesabı gibi sabit yüzdeyle büyümez. Yeni öğrendiklerini önceki bilgilere bağladığında sonraki konuları anlamak kolaylaşabilir. Roma hakkında biraz öğrendiğinde Avrupa tarihiyle ilgili bir haber daha anlamlı hâle gelir.

Bugün sadece bir kelime öğrenmek küçük görünebilir. Ama o kelimeyi yarın kullanmak ve haftaya hatırlamak, bilginin zihninde yer edinmesine yardım eder.
''','100 TL yıllık %10 getiriyle iki yıl boyunca getirisi de içeride kalırsa kaç TL olur?',['110 TL','120 TL','121 TL','122 TL'],2,'İlk yıl 100 × 1,10 = 110 TL; ikinci yıl 110 × 1,10 = 121 TL olur.',['bilesik','oran','birikim'])

r('kritik','Bilim','İnternette gördüğün her bilgi neden eşit değil?','Kaynak, kanıt ve küçük bir kontrol listesi.',3,'''
Bir video çok kendinden emin konuşuyor diye içindeki bilgi doğru olmak zorunda değildir. Benzer şekilde, az izlenen bir araştırma sonucu da sırf az kişi gördü diye yanlış sayılmaz. İddiaların güvenilirliği, onları kimin söylediğinden bağımsız olmayan ama onunla sınırlı da kalmayan bir konudur.

İlk bakılacak noktalardan biri kaynaktır. İddia bilimsel bir çalışmaya mı dayanıyor, yoksa yalnızca başka bir sosyal medya hesabına mı atıf yapıyor? Çalışmanın ne zaman yapıldığı, hangi grubu incelediği ve sonucun ne kadar kesin olduğu önemlidir.

İkinci nokta bağlamdır. Bir istatistik başlıkta etkileyici görünebilir. Ancak sayıların hangi yıla, hangi ülkeye veya hangi gruba ait olduğunu bilmeden genelleme yapmak yanıltıcı olabilir.

Üçüncü nokta karşılaştırmadır. Güvenilir bağımsız kaynaklar aynı temel olayı doğruluyor mu? Aralarında fark varsa bunun nedeni ölçüm yöntemi, güncelleme tarihi veya gerçek bir anlaşmazlık olabilir.

Son olarak, bilmiyorum demek bilgiye karşı bir zayıflık değildir. Bazen en doğru cevap “Bu iddiayı kontrol etmem gerek”tir. Merak, her şeye inanmak ile her şeyi reddetmek arasında daha dikkatli bir yol açar.
''','Bir internet iddiasını değerlendirirken ilk olarak hangisi önemlidir?',['Yalnızca beğeni sayısı','Kaynağın ve kanıtın niteliği','Videodaki müzik','Paylaşan hesabın profil rengi'],1,'Kaynağın güvenilirliği, kanıtın içeriği ve bağlamı değerlendirmek esastır.',['kaynak','baglam','kanit'])

r('orijinal','Öykü','Gece kütüphanesindeki son çekmece','MERAK için yazılmış özgün kısa öykü.',4,'''
Kütüphane kapanalı on dakika olmuştu. Arda görevliye yardım etmek için masaları topluyor, yerde kalan kitapları raflarına yerleştiriyordu. Son sıradaki masanın altında küçük, pirinçten bir anahtar gördü. Anahtarın üzerinde tek kelime yazıyordu: “Yarın.”

Arda anahtarı danışmaya götürdü. Yaşlı görevli gözlüğünün üzerinden baktı. “Burada öyle bir çekmece yok,” dedi. Sonra kısa bir sessizlik oldu. “Yine de kayıp eşya kutusuna bak.”

Kayıp eşya dolabının içinde, diğerlerinden daha eski görünen ince bir çekmece vardı. Üzerine sayı yerine bir tarih yazılmıştı: Arda'nın ertesi günkü doğum tarihi. Anahtar kilide uydu. Çekmecede bir defter ve boş bir sayfa bulunuyordu.

Defterin kapağında “Henüz yapılmamış şeyler” yazıyordu. İçinde büyük başarılar yoktu. Birinin aranmamış telefonu, başlanmamış bir yürüyüş, okunmamış ince bir kitap… Son sayfada tek bir cümle vardı: “Yarın dediğin gün, sabah olunca bugün olur.”

Arda defteri kapattı. Bunun bir şaka olup olmadığını anlamadı. Belki görevli ona küçük bir oyun hazırlamıştı. Belki de çekmece yıllardır oradaydı ve birileri bu cümleleri yazıp bırakmıştı. Anahtarı yerine koydu.

Eve giderken telefonunu çıkardı. Ertelediği uzun bir mesajı yazmak yerine arkadaşını aradı. Konuşmaları sadece üç dakika sürdü. Fakat ertesi gün, dünden farklı başladı.

Arda kütüphaneye döndüğünde çekmece yerindeydi. Kilidi açıktı. İçindeki defterin ilk sayfasına biri yeni bir başlık atmıştı: “Bugün.”
''','Arda’nın bulduğu anahtarın üzerinde hangi kelime yazıyordu?',['Dün','Yarın','Şimdi','Sonra'],1,'Öyküde pirinç anahtarın üzerinde “Yarın” kelimesi yer alır.',['ertelemek','kararlilik','olasılık'])

words=[]
def w(id,word,meaning,example,alternative,category): words.append(dict(id=id,word=word,meaning=meaning,example=example,alternative=alternative,category=category))
w('kaniksamak','Kanıksamak','Tekrarlanan bir durumu zamanla olağan karşılamaya başlamak.','Başta garipsediği sessizliği zamanla kanıksadı.','Alışmak; fakat çoğu zaman duyarsızlaşma anlamı da taşır.','Düşünce')
w('yabancilasma','Yabancılaşma','Kişinin kendine, çevresine veya yaptığı işe uzaklık hissetmesi.','Kalabalığın içinde yabancılaşma hissi yaşadı.','Uzaklaşma.','Düşünce')
w('celiski','Çelişki','İki düşüncenin veya durumun birbiriyle uyuşmaması.','Sözleriyle davranışları arasında çelişki vardı.','Tutarsızlık.','Günlük')
w('vicdan','Vicdan','Kişinin davranışlarını ahlaki açıdan değerlendirmesini sağlayan içsel duygu ve yargı.','Vicdanı onu gerçeği söylemeye yöneltti.','Ahlaki iç değerlendirme.','Düşünce')
w('gerekce','Gerekçe','Bir düşünceyi veya davranışı açıklayan neden.','Kararının gerekçesini açıkça anlattı.','Neden, dayanak.','Günlük')
w('merhamet','Merhamet','Başkasının acısı karşısında duyulan şefkat ve yardım etme isteği.','Sokaktaki hayvana merhametle yaklaştı.','Şefkat.','Duygular')
w('tatmin','Tatmin','Bir ihtiyacın veya isteğin karşılanmasıyla duyulan doyum.','Sonuçtan tatmin olmadı.','Doyum.','Duygular')
w('muhakeme','Muhakeme','Bilgileri değerlendirerek bir sonuca varma, akıl yürütme.','Hızlı karar vermeden önce muhakeme etti.','Akıl yürütme.','Düşünce')
w('arayis','Arayış','Bir amaç, anlam veya çözüm bulmaya yönelik çaba.','Kendine uygun bir yol arayışındaydı.','Araştırma, arama.','Düşünce')
w('gözetim','Gözetim','Bir kişi, yer veya faaliyetin izlenmesi ve denetlenmesi.','Binada güvenlik gözetimi vardı.','İzleme, denetim.','Günlük')
w('ifade','İfade','Duygu, düşünce veya bilgiyi sözle, yazıyla ya da başka yolla anlatma.','Düşüncesini sakin bir ifadeyle aktardı.','Anlatım.','Günlük')
w('manipulasyon','Manipülasyon','Birini veya bilgiyi istenen sonuca yönlendirmek için etkileme ya da çarpıtma.','Başlık, okuyucunun duygularını manipüle ediyordu.','Yönlendirme.','Düşünce')
w('gozlem','Gözlem','Bir olayı veya durumu dikkatle inceleme ve izleme.','Bahçedeki kuşları gözlemledi.','İzleme, inceleme.','Bilim')
w('onyargi','Önyargı','Yeterli bilgi olmadan önceden oluşturulan olumlu veya olumsuz yargı.','Onu tanımadan önyargıya kapıldı.','Peşin hüküm.','Düşünce')
w('ayrinti','Ayrıntı','Bir bütünün küçük ama anlamlı parçası.','Hikâyedeki küçük ayrıntıyı fark etti.','Detay.','Günlük')
w('absurt','Absürt','Alışılmış mantık veya beklentilerle uyuşmayan, saçma görünen.','Absürt bir durumla karşılaştı.','Saçma, uyumsuz.','Düşünce')
w('anlam','Anlam','Bir sözün, işaretin veya olayın ifade ettiği şey.','Bu sözün anlamını araştırdı.','Mana.','Düşünce')
w('bilinc','Bilinç','Kişinin kendisinin ve çevresinin farkında olma durumu.','Kararını bilinçli biçimde verdi.','Farkındalık.','Düşünce')
w('irade','İrade','Seçme, karar verme ve davranışı yönlendirme gücü.','İradesini kullanıp çalışmaya başladı.','Karar gücü.','Düşünce')
w('tepkı','Tepki','Bir olay veya etkiye verilen karşılık.','Eleştiriye sakin tepki verdi.','Karşılık.','Günlük')
w('kabullenme','Kabullenme','Bir gerçeği inkâr etmeden varlığını kabul etme.','Değiştiremeyeceği durumu kabullenmeye çalıştı.','Kabul etme.','Duygular')
w('sorgulama','Sorgulama','Bir düşüncenin doğruluğunu nedenleriyle inceleme.','Duyduğu iddiayı sorguladı.','İrdeleme.','Düşünce')
w('kanit','Kanıt','Bir iddiayı destekleyen, doğrulayan bilgi veya bulgu.','İddiasına sağlam kanıt gösterdi.','Delil.','Bilim')
w('varsayim','Varsayım','Doğruluğu henüz gösterilmemiş, geçici olarak kabul edilen düşünce.','Planını yanlış bir varsayıma dayandırdı.','Kabul.','Düşünce')
w('imparatorluk','İmparatorluk','Farklı bölgeleri veya halkları yönetebilen geniş siyasi yapı.','İmparatorluk yüzyıllar boyunca değişti.','Büyük devlet yapısı.','Tarih')
w('miras','Miras','Geçmişten sonraki kuşaklara kalan maddi veya kültürel değer.','Şehrin tarihî mirası korundu.','Kalıt, geçmişten kalan değer.','Tarih')
w('donum','Dönüm noktası','Bir sürecin yönünü önemli ölçüde değiştiren olay veya zaman.','Bu karar hayatında dönüm noktası oldu.','Kritik eşik.','Günlük')
w('erisim','Erişim','Bir bilgiye, yere veya hizmete ulaşabilme.','Kaynağa erişim kolaylaştı.','Ulaşma.','Günlük')
w('yayilim','Yayılım','Bir şeyin farklı alanlara veya kişilere dağılması.','Bilginin yayılımı hızlandı.','Yayılma.','Bilim')
w('kaynak','Kaynak','Bilgi veya malzemenin elde edildiği yer ya da temel.','Haberdeki kaynağı kontrol etti.','Dayanak, menşe.','Günlük')
w('projeksiyon','Projeksiyon','Küresel bir yüzeyi düzleme aktarma yöntemi veya öngörü.','Haritanın projeksiyonu alanları çarpıttı.','Haritada izdüşüm.','Bilim')
w('olcek','Ölçek','Bir büyüklüğün başka bir gösterimdeki orantısı.','Grafiğin ölçeğine dikkat etti.','Oranlama düzeni.','Bilim')
w('algı','Algı','Duyulardan gelen bilgilerin zihinde yorumlanması.','Aynı olayı farklı algıladılar.','İdrak.','Düşünce')
w('yanilsama','Yanılsama','Gerçekte olandan farklı algılama veya değerlendirme.','Görsel yanılsama çizgiyi uzun gösterdi.','İllüzyon.','Bilim')
w('hafiza','Hafıza','Bilgileri öğrenme, saklama ve yeniden hatırlama kapasitesi.','Kelimeyi hafızasında tutmak için tekrar etti.','Bellek.','Bilim')
w('hemosiyanin','Hemosiyanin','Bazı omurgasızlarda oksijen taşıyan, bakır içeren protein.','Ahtapot kanındaki hemosiyanin oksijen taşır.','Biyolojik oksijen taşıyıcısı.','Bilim')
w('dolasim','Dolaşım','Kan gibi sıvıların canlı vücudunda hareket etmesi.','Kalp dolaşım sisteminin bir parçasıdır.','Sirkülasyon.','Bilim')
w('evrim','Evrim','Canlı popülasyonlarının kalıtsal özelliklerinin kuşaklar boyunca değişmesi.','Evrim biyolojinin temel konularındandır.','Kuşaklar boyu kalıtsal değişim.','Bilim')
w('mesafe','Mesafe','İki nokta arasındaki uzaklık.','İki şehir arasındaki mesafeyi ölçtü.','Uzaklık.','Günlük')
w('gozlem','Gözlem','Bir olayı dikkatle izleyerek bilgi edinme.','Deneyi gözlemledi.','İnceleme.','Bilim')
w('astronomi','Astronomi','Gök cisimlerini ve evreni inceleyen bilim dalı.','Astronomi dersinde yıldızları öğrendi.','Gök bilimi.','Bilim')
w('surtunme','Sürtünme','Hareketi zorlaştıran etki; mecazen işe başlamayı zorlaştıran engel.','Hazırlık süresi işe başlama sürtünmesini artırdı.','Engel.','Günlük')
w('istikrar','İstikrar','Bir davranış veya durumun tutarlı biçimde sürmesi.','Küçük adımlarla istikrar kazandı.','Süreklilik, kararlılık.','Günlük')
w('erteleme','Erteleme','Yapılması gereken bir işi daha sonraya bırakma.','Erteleme yüzünden işi yetişmedi.','Geciktirme.','Günlük')
w('ozsaygi','Özsaygı','Kişinin kendisine duyduğu değer ve saygı.','Kendini sürekli aşağılamak özsaygısını zorlayabilir.','Kendine saygı.','Duygular')
w('ozguven','Özgüven','Bir işi yapabilme gücüne veya becerisine ilişkin inanç.','Tekrar ettikçe sunum özgüveni arttı.','Kendine güven.','Duygular')
w('sureklilik','Süreklilik','Bir şeyin kesintisiz ya da düzenli biçimde sürmesi.','Öğrenmede süreklilik önemliydi.','Devamlılık.','Günlük')
w('rutin','Rutin','Düzenli aralıklarla tekrarlanan alışkanlık veya iş.','Akşam rutinini sadeleştirdi.','Alışılmış düzen.','Günlük')
w('dinlenme','Dinlenme','Bedensel ve zihinsel yükten uzaklaşarak güç toplama.','Yoğun antrenmandan sonra dinlenmeye zaman ayırdı.','İstirahat.','Günlük')
w('tutarlilik','Tutarlılık','Söz, düşünce ve davranışların birbiriyle uyumlu olması.','Kararlarında tutarlılık gösterdi.','Uyumluluk.','Günlük')
w('enflasyon','Enflasyon','Genel fiyat düzeyinin zaman içinde yükselmesi.','Enflasyon alım gücünü etkiledi.','Genel fiyat artışı.','Ekonomi')
w('alim_gucu','Alım gücü','Belli bir para miktarıyla satın alınabilen mal ve hizmet miktarı.','Fiyatlar artınca alım gücü azaldı.','Satın alma kapasitesi.','Ekonomi')
w('deflasyon','Deflasyon','Genel fiyat düzeyinin düşmesi.','Deflasyon döneminde genel fiyatlar gerileyebilir.','Genel fiyat düşüşü.','Ekonomi')
w('bilesik','Bileşik getiri','Getirinin sonraki dönemde yeni getiri hesabına katılması.','Bileşik getiri örneğinde ilk kazanç yeniden hesaba girdi.','Getirinin getirisi.','Ekonomi')
w('oran','Oran','İki büyüklüğün birbirine göre niceliksel karşılaştırması.','Sınavdaki başarı oranına baktı.','Nispet.','Ekonomi')
w('birikim','Birikim','Zaman içinde toplanan para, bilgi veya deneyim.','Küçük öğrenmeler zamanla birikim oluşturdu.','Birikmiş değer.','Günlük')
w('baglam','Bağlam','Bir sözün veya olayın doğru anlaşılmasını sağlayan çevresel koşullar.','Cümleyi bağlamından koparma.','İlgili koşullar.','Düşünce')
w('ertelemek','Ertelemek','Planlanan bir işi daha sonraya bırakmak.','Uzun zamandır yürüyüşü erteliyordu.','Geciktirmek.','Günlük')
w('kararlilik','Kararlılık','Bir amacı izlemekte gösterilen sağlam irade.','Kararlılıkla küçük adımını attı.','Azim.','Günlük')
w('olasılık','Olasılık','Bir olayın gerçekleşme ihtimali.','Yağmur yağma olasılığını düşündü.','İhtimal.','Bilim')

# A few data points worth questioning: avoid repeated IDs.
seen=set(); unique=[]
for obj in words:
 if obj['id'] not in seen: unique.append(obj); seen.add(obj['id'])
words=unique

facts=[
 ('Bilim','Ahtapotların üç kalbi vardır.','İki kalp kanı solungaçlara, üçüncüsü ise vücudun diğer bölümlerine pompalar.'),
 ('Uzay','Güneş ışığı Dünya’ya yaklaşık 8 dakika 20 saniyede ulaşır.','Işık son derece hızlıdır ama Güneş ve Dünya arasındaki yolculuk da zaman alır.'),
 ('Coğrafya','Afrika, Grönland’dan yaklaşık 14 kat büyüktür.','Yaygın dünya haritalarındaki projeksiyon yüksek enlemlerdeki alanları büyük gösterir.'),
 ('Dil','Türkçede “de” bağlacı ve “-de” eki aynı şey değildir.','“Ben de geldim” cümlesinde ayrı, “evde kaldım” cümlesinde bitişik yazılır.'),
 ('Tarih','476 yılı Batı Roma için geleneksel bir dönüm noktasıdır.','Doğu Roma İmparatorluğu ise varlığını 1453’e kadar sürdürmüştür.'),
 ('Bilim','Işık yılı, zaman değil uzaklık birimidir.','Işığın bir yılda boşlukta katettiği mesafeyi ifade eder.'),
 ('Edebiyat','Kafka’nın Dönüşüm eseri ilk kez 1915’te yayımlandı.','Gregor Samsa’nın dönüşümü, yabancılaşma ve aile ilişkileri üzerine tartışmalara yol açmıştır.'),
 ('Tarih','Gutenberg’den önce de baskı teknikleri vardı.','Doğu Asya’da Avrupa’daki Gutenberg sistemi öncesinde baskı yöntemleri kullanılmıştı.'),
 ('Doğa','Arıların bazıları yön bilgisi aktarmak için dans eder.','Bal arıları bir besin kaynağının yönü ve uzaklığı hakkında işaretler iletebilir.'),
 ('Psikoloji','Hatırlamak, kusursuz bir video kaydını açmak değildir.','Bellek yeniden yapılandırıcıdır; zaman ve beklentiler ayrıntıları etkileyebilir.'),
 ('Ekonomi','Enflasyonun azalması fiyatların mutlaka düşmesi değildir.','Enflasyon düşerken genel fiyatlar artmaya devam edebilir; yalnızca artış hızı azalır.'),
 ('Coğrafya','Dünya’nın en derin okyanus çukuru Mariana Çukuru’dur.','Pasifik Okyanusu’nda bulunur; ölçümlere göre en derin noktası yaklaşık 11 kilometredir.'),
 ('Uzay','Ay, Dünya’dan her yıl ortalama yaklaşık 3,8 cm uzaklaşır.','Ay yüzeyine yerleştirilmiş yansıtıcılar üzerinden yapılan lazer ölçümleri bu değişimi gösterir.'),
 ('Dil','“Mütevazı” alçakgönüllü anlamına gelir.','“Mütevazi” biçimi gündelik yazılarda görülse de standart yazım “mütevazı”dır.'),
 ('Tarih','Fransız Devrimi 1789’da başladı.','Avrupa’daki siyasal ve toplumsal düşünceyi derinden etkileyen bir süreçtir.'),
 ('Doğa','Bazı ağaçların kökleri mantarlarla ortak yaşam kurar.','Mikoriza denen ilişkilerde mantarlar ve bitkiler kaynak alışverişi yapabilir.'),
 ('Bilim','Saf su deniz seviyesinde yaklaşık 100 °C’de kaynar.','Kaynama noktası basınca bağlıdır; yüksek rakımda daha düşük olabilir.'),
 ('Edebiyat','Goethe’nin Faust eseri tek bölümden oluşmaz.','Eserin birinci ve ikinci bölümleri farklı tarihlerde yayımlanmıştır.'),
 ('Düşünce','Bir fikri değiştirmek her zaman tutarsızlık değildir.','Yeni ve güçlü kanıtlar karşısında görüşü gözden geçirmek akılcı olabilir.'),
 ('Coğrafya','Antarktika aynı zamanda bir çöldür.','Çöller yalnızca sıcaklığa göre değil, çok az yağış almalarına göre de tanımlanır.'),
 ('Bilim','Ses boşlukta yayılamaz.','Sesin yayılması için hava, su veya başka bir madde ortamı gerekir.'),
 ('Ekonomi','Yüzde 20 indirimden sonra yüzde 20 zam ilk fiyata döndürmez.','100 TL → 80 TL → 96 TL olur; yüzdeler farklı tabanlardan hesaplanır.'),
 ('Dünya','İstanbul iki kıtada yer alır.','Boğaz, Avrupa ve Asya yakalarını birbirinden ayırır.'),
 ('Edebiyat','1984 romanının yazarı George Orwell’dir.','Roman gözetim, dil ve iktidar üzerine düşünmeye davet eder.'),
]
facts=[dict(id=f'f{i+1}',category=a,title=b,body=c) for i,(a,b,c) in enumerate(facts)]

# Correctness and uniqueness check
assert len(set(x['id'] for x in readings))==len(readings)
assert len(set(x['id'] for x in words))==len(words)
assert all(0<=r['answer']<4 and len(r['options'])==4 for r in readings)
assert all(len(r['paragraphs'])>=4 for r in readings)
assert all(all(i in set(x['id'] for x in words) for i in r['wordIds']) for r in readings)
data={'version':1,'readings':readings,'words':words,'facts':facts}
out.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print('OK',len(readings),'readings',len(words),'words',len(facts),'facts',out.stat().st_size,'bytes')
