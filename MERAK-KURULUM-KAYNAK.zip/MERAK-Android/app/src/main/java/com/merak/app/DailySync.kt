package com.merak.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/** Android may delay background work to save battery; on-open refresh is the reliable path. */
class DailyContentWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val store = MerakStore(applicationContext)
            if (store.cachedDate() == dayKey()) return Result.success()
            val items = WikiSource.daily()
            if (items.isEmpty()) Result.retry() else {
                store.saveStories(items)
                Result.success()
            }
        } catch (_: Exception) { Result.retry() }
    }
}

object DailySync {
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<DailyContentWorker>(24, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "merak_daily_sources", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}
