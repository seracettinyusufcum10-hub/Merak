package com.merak.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.Locale

/** Offline-first content. Personal data is stored only on the device. */
data class Reading(
    val id: String,
    val category: String,
    val title: String,
    val subtitle: String,
    val minutes: Int,
    val paragraphs: List<String>,
    val question: String,
    val options: List<String>,
    val answer: Int,
    val explanation: String,
    val wordIds: List<String>
)
data class Word(val id: String, val word: String, val meaning: String, val example: String, val alternative: String, val category: String)
data class Fact(val id: String, val category: String, val title: String, val body: String)
data class WebStory(val id: String, val title: String, val intro: String, val link: String, val topic: String)
data class ContentPack(val readings: List<Reading>, val words: List<Word>, val facts: List<Fact>)

fun dayKey(): String = LocalDate.now().toString()
fun dayNumber(): Long = LocalDate.now().toEpochDay()
private fun JSONArray.textList(): List<String> = (0 until length()).map { optString(it) }

class MerakStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("merak_local_v1", Context.MODE_PRIVATE)
    private val pack by lazy { loadPack() }
    val content: ContentPack get() = pack
    private fun loadPack(): ContentPack {
        val root = JSONObject(context.assets.open("content.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
        val readings = root.getJSONArray("readings").let { arr -> (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Reading(o.getString("id"), o.getString("category"), o.getString("title"), o.getString("subtitle"),
                o.optInt("minutes", 4), o.getJSONArray("paragraphs").textList(), o.getString("question"),
                o.getJSONArray("options").textList(), o.getInt("answer"), o.getString("explanation"),
                o.getJSONArray("wordIds").textList())
        }}
        val words = root.getJSONArray("words").let { arr -> (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Word(o.getString("id"), o.getString("word"), o.getString("meaning"), o.getString("example"),
                o.getString("alternative"), o.optString("category", "Kelime"))
        }}
        val facts = root.getJSONArray("facts").let { arr -> (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Fact(o.getString("id"), o.getString("category"), o.getString("title"), o.getString("body"))
        }}
        return ContentPack(readings, words, facts)
    }

    var mood: String
        get() = prefs.getString("mood_${dayKey()}", "") ?: ""
        set(v) { prefs.edit().putString("mood_${dayKey()}", v).apply() }
    var nightNote: String
        get() = prefs.getString("note_${dayKey()}", "") ?: ""
        set(v) { prefs.edit().putString("note_${dayKey()}", v).apply() }
    var bedtimePlan: Boolean
        get() = prefs.getBoolean("bedtime_${dayKey()}", false)
        set(v) { prefs.edit().putBoolean("bedtime_${dayKey()}", v).apply() }
    private fun getSet(key: String): Set<String> = prefs.getStringSet(key, emptySet())?.toSet() ?: emptySet()
    fun isRead(id: String) = id in getSet("read_ids")
    fun readCount(): Int = getSet("read_ids").size
    fun toggleRead(id: String) {
        val values = getSet("read_ids").toMutableSet()
        if (!values.add(id)) values.remove(id)
        prefs.edit().putStringSet("read_ids", values).apply()
    }
    fun isSaved(id: String) = id in getSet("saved_ids")
    fun toggleSaved(id: String) {
        val values = getSet("saved_ids").toMutableSet()
        if (!values.add(id)) values.remove(id)
        prefs.edit().putStringSet("saved_ids", values).apply()
    }
    fun knowWord(id: String) = id in getSet("known_words")
    fun toggleWord(id: String) {
        val values = getSet("known_words").toMutableSet()
        if (!values.add(id)) values.remove(id)
        prefs.edit().putStringSet("known_words", values).apply()
    }
    fun knownCount(): Int = getSet("known_words").size
    fun hasCompletedToday() = dayKey() in getSet("completed_days")
    fun completionDays(): Int = getSet("completed_days").size
    fun completeToday() {
        val values = getSet("completed_days").toMutableSet().apply { add(dayKey()) }
        prefs.edit().putStringSet("completed_days", values).apply()
    }

    // Last successful daily download remains readable without internet.
    fun cachedDate(): String = prefs.getString("web_date", "") ?: ""
    fun cachedStories(): List<WebStory> = runCatching {
        val a = JSONArray(prefs.getString("web_stories", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            WebStory(o.getString("id"), o.getString("title"), o.getString("intro"),
                o.getString("link"), o.optString("topic", "Keşif"))
        }
    }.getOrDefault(emptyList())
    fun saveStories(stories: List<WebStory>) {
        val a = JSONArray()
        stories.forEach { item -> a.put(JSONObject().put("id", item.id).put("title", item.title)
            .put("intro", item.intro).put("link", item.link).put("topic", item.topic)) }
        prefs.edit().putString("web_date", dayKey()).putString("web_stories", a.toString()).apply()
    }
}

/**
 * Wikipedia supplies new source-attributed extracts; no AI API key, backend or account.
 * The offline literary readings are original. This live layer is encyclopedic, not novel text.
 */
object WikiSource {
    private const val BASE = "https://tr.wikipedia.org/w/api.php"
    // Many voices, eras and regions; NOT a restriction on which author the user can search.
    private val authors = listOf(
        "Virginia Woolf", "Jorge Luis Borges", "Emily Dickinson", "Gabriel García Márquez", "Oscar Wilde",
        "Yaşar Kemal", "Oğuz Atay", "Sabahattin Ali", "Halide Edib Adıvar", "Ahmet Hamdi Tanpınar",
        "Mihail Bulgakov", "Lev Tolstoy", "Anton Çehov", "Nikolay Gogol", "Stefan Zweig",
        "Albert Camus", "Jean-Paul Sartre", "Simone de Beauvoir", "Hermann Hesse", "Herman Melville",
        "Mary Shelley", "Jane Austen", "Charlotte Brontë", "Victor Hugo", "Honoré de Balzac",
        "Italo Calvino", "Umberto Eco", "José Saramago", "Fernando Pessoa", "Franz Kafka",
        "Fyodor Dostoyevski", "Johann Wolfgang von Goethe", "George Orwell", "William Shakespeare", "Miguel de Cervantes",
        "Mevlânâ Celâleddîn-i Rûmî", "Yunus Emre", "Nâzım Hikmet", "Orhan Veli Kanık", "Sait Faik Abasıyanık",
        "Toni Morrison", "James Baldwin", "Ursula K. Le Guin", "Octavia Butler", "Agatha Christie",
        "Rabindranath Tagore", "Haruki Murakami", "Chinua Achebe", "Frida Kahlo", "Montaigne",
        "Epiktetos", "Marcus Aurelius", "Hannah Arendt", "Friedrich Nietzsche", "İbn Haldun"
    )
    private val topics = listOf(
        "felsefe", "kozmoloji", "bilim tarihi", "psikoloji", "antik uygarlıklar", "ekoloji", "astronomi",
        "Türk edebiyatı", "sanat tarihi", "mimarlık", "dünya coğrafyası", "fizik", "matematik tarihi",
        "deniz biyolojisi", "ekonomi", "dilbilim", "uyku", "müzik tarihi", "mitoloji", "nörobilim",
        "buluşlar", "Orta Çağ", "arkeoloji", "gezegenler", "insan hakları", "Rönesans"
    )

    suspend fun daily(): List<WebStory> = withContext(Dispatchers.IO) {
        val day = dayNumber()
        val author = authors[Math.floorMod(day, authors.size.toLong()).toInt()]
        val topic = topics[Math.floorMod(day / 3 + 7, topics.size.toLong()).toInt()]
        val authorStories = searchBlocking(author, 4, "Yazarlar")
        val topicStories = searchBlocking(topic, 4, "Bunu biliyor muydun?")
        // Preserve two genuinely new requests per day, avoid duplicate result IDs.
        (authorStories.take(2) + topicStories.take(3)).distinctBy { it.id }.take(5)
    }

    suspend fun search(query: String): List<WebStory> = withContext(Dispatchers.IO) {
        if (query.isBlank()) emptyList() else searchBlocking(query.trim().take(90), 12, "Arama sonucu")
    }

    private fun searchBlocking(query: String, limit: Int, topic: String): List<WebStory> {
        val params = listOf(
            "action" to "query", "generator" to "search", "gsrsearch" to query, "gsrnamespace" to "0",
            "gsrlimit" to limit.toString(), "prop" to "extracts|info", "exintro" to "1",
            "explaintext" to "1", "exchars" to "700", "inprop" to "url", "format" to "json",
            "formatversion" to "2"
        )
        val uri = Uri.parse(BASE).buildUpon().apply { params.forEach { (k,v) -> appendQueryParameter(k,v) } }.build().toString()
        val connection = (URL(uri).openConnection() as HttpURLConnection)
        connection.requestMethod = "GET"
        connection.connectTimeout = 9000
        connection.readTimeout = 9000
        connection.setRequestProperty("User-Agent", "MERAKReader/0.1 (Android; educational reader; https://tr.wikipedia.org)")
        connection.setRequestProperty("Accept", "application/json")
        try {
            if (connection.responseCode !in 200..299) return emptyList()
            val payload = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(payload).optJSONObject("query") ?: return emptyList()
            val pages = root.optJSONArray("pages") ?: return emptyList()
            (0 until pages.length()).mapNotNull { index ->
                val page = pages.getJSONObject(index)
                val title = page.optString("title", "").trim()
                val extract = page.optString("extract", "").replace(Regex("\\s+"), " ").trim()
                val id = page.optLong("pageid", 0L)
                if (title.length < 3 || extract.length < 100 || id <= 0) null
                else WebStory("wikipedia_$id", title, extract.take(650).trimEnd() + if (extract.length > 650) "…" else "",
                    "https://tr.wikipedia.org/?curid=$id", topic)
            }
        } finally { connection.disconnect() }
    }
}
