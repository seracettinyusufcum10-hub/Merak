package com.merak.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Navy = Color(0xFF0D1925)
private val Panel = Color(0xFF182A39)
private val PanelLight = Color(0xFF223747)
private val Gold = Color(0xFFE2BD87)
private val Cream = Color(0xFFF2E8D9)
private val Muted = Color(0xFFACBAC6)
private val Line = Color(0xFF2C4050)
private val Green = Color(0xFF9DC9B3)

class MainActivity : ComponentActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 25, 37)
        window.navigationBarColor = android.graphics.Color.rgb(13, 25, 37)
        DailySync.schedule(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Gold, onPrimary = Navy,
                background = Navy, onBackground = Cream,
                surface = Panel, onSurface = Cream,
                secondary = Muted, onSecondary = Navy
            )) {
                MerakApp()
            }
        }
    }
}

private enum class Tab(val label: String) { TODAY("Günüm"), DISCOVER("Keşfet"), WORDS("Kelimeler"), YOU("Ben") }

@Composable
private fun MerakApp() {
    val context = LocalContext.current
    val store = remember { MerakStore(context) }
    val pack = remember { store.content }
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf(Tab.TODAY) }
    var selectedReadingId by rememberSaveable { mutableStateOf("") }
    var selectedWeb by remember { mutableStateOf<WebStory?>(null) }
    var stateVersion by remember { mutableIntStateOf(0) }
    var webItems by remember { mutableStateOf(store.cachedStories()) }
    var refreshing by remember { mutableStateOf(false) }
    var updateError by remember { mutableStateOf("") }
    var searchText by rememberSaveable { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<WebStory>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf("") }
    val sourceDate = store.cachedDate()

    fun refreshDaily(force: Boolean = false) {
        if (refreshing || (!force && store.cachedDate() == dayKey())) return
        refreshing = true
        updateError = ""
        scope.launch {
            try {
                val results = WikiSource.daily()
                if (results.isNotEmpty()) {
                    store.saveStories(results)
                    webItems = results
                } else updateError = "Yeni içerik alınamadı. Çevrimdışı içerikler kullanılabilir."
            } catch (_: Exception) {
                updateError = "Bağlantı kurulamadı. Son indirilen içerikler duruyor."
            } finally { refreshing = false }
        }
    }
    LaunchedEffect(Unit) {
        // Foreground refresh is reliable when the app is opened; WorkManager also attempts a daily sync.
        if (store.cachedDate() != dayKey()) refreshDaily()
    }
    fun doSearch() {
        if (searchText.isBlank() || searching) return
        searching = true
        searched = true
        searchError = ""
        scope.launch {
            try { searchResults = WikiSource.search(searchText) }
            catch (_: Exception) {
                searchResults = emptyList()
                searchError = "Şu anda internete bağlanılamıyor."
            } finally { searching = false }
        }
    }
    fun openUrl(url: String) {
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }
    fun openReading(id: String) { selectedWeb = null; selectedReadingId = id }
    fun openWeb(item: WebStory) { selectedReadingId = ""; selectedWeb = item }
    fun backToList() { selectedReadingId = ""; selectedWeb = null }

    BackHandler(enabled = selectedReadingId.isNotBlank() || selectedWeb != null) { backToList() }
    Scaffold(
        containerColor = Navy,
        bottomBar = {
            NavigationBar(containerColor = Panel, tonalElevation = 0.dp) {
                Tab.entries.forEach { page ->
                    val icon = when (page) {
                        Tab.TODAY -> Icons.Default.Home
                        Tab.DISCOVER -> Icons.Default.Explore
                        Tab.WORDS -> Icons.Default.MenuBook
                        Tab.YOU -> Icons.Default.Person
                    }
                    NavigationBarItem(
                        selected = tab == page,
                        onClick = { tab = page; backToList() },
                        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp)) },
                        label = { Text(page.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold, selectedTextColor = Gold,
                            unselectedIconColor = Muted, unselectedTextColor = Muted,
                            indicatorColor = PanelLight
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.fillMaxWidth().widthIn(max = 700.dp)) {
                when {
                    selectedReadingId.isNotBlank() -> {
                        val reading = pack.readings.firstOrNull { it.id == selectedReadingId }
                        if (reading != null) ReadingPage(
                            reading, store.isRead(reading.id), store.isSaved(reading.id),
                            onBack = ::backToList, onRead = { store.toggleRead(reading.id); store.completeToday(); stateVersion++ },
                            onSave = { store.toggleSaved(reading.id); stateVersion++ },
                            words = pack.words.filter { it.id in reading.wordIds }
                        )
                    }
                    selectedWeb != null -> OnlineArticle(selectedWeb!!, onBack = ::backToList, onOpen = ::openUrl)
                    else -> when (tab) {
                        Tab.TODAY -> HomePage(store, pack, webItems, refreshing, updateError,
                            onRefresh = { refreshDaily(true) }, onReading = ::openReading, onWeb = ::openWeb,
                            onMood = { store.mood = it; stateVersion++ }, onOpenDiscover = { tab = Tab.DISCOVER })
                        Tab.DISCOVER -> DiscoverPage(pack, webItems, sourceDate, refreshing, updateError,
                            searchText, { searchText = it }, ::doSearch, searching, searched, searchError, searchResults,
                            onRefresh = { refreshDaily(true) }, onReading = ::openReading, onWeb = ::openWeb)
                        Tab.WORDS -> WordsPage(store, pack.words, onChange = { stateVersion++ })
                        Tab.YOU -> ProfilePage(store, onChange = { stateVersion++ })
                    }
                }
            }
        }
    }
    // Explicit state reads make local preference updates reactive.
    @Suppress("UNUSED_VARIABLE") val revision = stateVersion
}

@Composable
private fun PageContent(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp), content = content
    )
}
@Composable
private fun SurfaceCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(17.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp), content = content
    )
}
@Composable
private fun Eyebrow(value: String) = Text(value.uppercase(Locale.forLanguageTag("tr")),
    color = Gold, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.3.sp)
@Composable
private fun LabelTitle(value: String, sub: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(value, color = Cream, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, lineHeight = 25.sp)
        if (sub != null) Text(sub, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
    }
}
@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(onClick = onClick, modifier = modifier, enabled = enabled, shape = RoundedCornerShape(13.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) {
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}
@Composable
private fun OutlinedSmall(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(onClick = onClick, modifier = modifier, enabled = enabled,
        shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
        Text(text, color = Gold, fontSize = 12.sp)
    }
}

@Composable
private fun HomePage(
    store: MerakStore, pack: ContentPack, live: List<WebStory>, refreshing: Boolean, updateError: String,
    onRefresh: () -> Unit, onReading: (String) -> Unit, onWeb: (WebStory) -> Unit,
    onMood: (String) -> Unit, onOpenDiscover: () -> Unit
) {
    val todayIndex = Math.floorMod(dayNumber(), pack.readings.size.toLong()).toInt()
    val selection = pack.readings[todayIndex]
    val dateText = LocalDate.now().format(DateTimeFormatter.ofPattern("d MMMM, EEEE", Locale.forLanguageTag("tr-TR")))
    PageContent {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Eyebrow(dateText)
                Text("MERAK", color = Cream, fontFamily = FontFamily.Serif, fontSize = 28.sp, letterSpacing = 2.sp)
            }
            Icon(Icons.Default.AutoStories, contentDescription = null, tint = Gold, modifier = Modifier.size(27.dp))
        }
        Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(20.dp))) {
            Image(painterResource(R.drawable.merak_cover), contentDescription = "MERAK kapak görseli",
                contentScale = ContentScale.Crop, alignment = Alignment.TopCenter, modifier = Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Navy.copy(alpha = 0.83f)))))
            Column(Modifier.align(Alignment.BottomStart).padding(17.dp)) {
                Eyebrow("Bugünün küçük yolculuğu")
                Text("Her gün yeni bir şey keşfet.", color = Cream,
                    fontSize = 17.sp, fontWeight = FontWeight.Medium)
            }
        }
        MoodCard(store.mood, onMood)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            LabelTitle("Bugün ne okuyalım?", "Ortalama birkaç dakika. İstediğin zaman bırakabilirsin.")
            ReadingTile(selection, onClick = { onReading(selection.id) }, label = "Günün okuması")
        }
        SurfaceCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                Eyebrow("İnternetten yeni keşifler")
                TextButton(onClick = onRefresh, enabled = !refreshing) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = Gold, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(if (refreshing) "Yükleniyor" else "Yenile", color = Gold, fontSize = 12.sp)
                }
            }
            if (live.isEmpty()) Text("İnternet bağlantısıyla her gün farklı konular ve yazarlar geliyor.", color = Muted, fontSize = 13.sp)
            live.take(2).forEach { item ->
                Column(Modifier.fillMaxWidth().clickable { onWeb(item) }.padding(vertical = 7.dp)) {
                    Text(item.topic, color = Gold, fontSize = 11.sp)
                    Text(item.title, color = Cream, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(item.intro, color = Muted, fontSize = 12.sp, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
                }
            }
            if (updateError.isNotBlank()) Text(updateError, color = Muted, fontSize = 11.sp)
            OutlinedSmall("Tüm keşifleri gör", onOpenDiscover)
        }
        val factIndex = Math.floorMod(dayNumber(), pack.facts.size.toLong()).toInt()
        val fact = pack.facts[factIndex]
        SurfaceCard {
            Eyebrow("Bunu biliyor muydun?")
            Text(fact.title, color = Cream, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(fact.body, color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
        }
        if (store.hasCompletedToday()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Green, modifier = Modifier.size(17.dp))
                Text("Bugün bir adım attın. Bu kadar yeterli olabilir.", color = Green, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun MoodCard(selected: String, onMood: (String) -> Unit) {
    val moods = listOf("İyi", "İdare eder", "Zor", "Enerjik")
    val advice = when (selected) {
        "İyi" -> "Bu enerjini küçük bir keşfe ayır. Bugün ilginç bir şey öğrenmek yeter."
        "İdare eder" -> "Her gün aynı hissetmek zorunda değilsin. Kendine beş dakikalık sakin bir alan aç."
        "Zor" -> "Bugün zorsa kendini sıkıştırma. Bir bardak su, yavaş bir nefes ve kısa bir okuma iyi bir başlangıç olabilir."
        "Enerjik" -> "Güzel! Merak ettiğin konulardan birini seç ve öğrendiğini bir cümleyle anlat."
        else -> "Ruh hâline göre küçük ve uygulanabilir bir öneri sunalım."
    }
    SurfaceCard {
        Eyebrow("Kendine kısa bir bakış")
        Text("Bugün nasılsın?", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            moods.forEach { m ->
                val active = selected == m
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (active) Gold else PanelLight).clickable { onMood(m) }
                    .padding(horizontal = 3.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
                    Text(m, fontSize = if (m == "İdare eder") 10.sp else 11.sp,
                        color = if (active) Navy else Cream, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1)
                }
            }
        }
        Text(advice, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun ReadingTile(reading: Reading, onClick: () -> Unit, label: String? = null) {
    SurfaceCard(Modifier.clickable(onClick = onClick)) {
        if (label != null) Eyebrow(label)
        Text(reading.title, color = Cream, fontFamily = FontFamily.Serif,
            fontSize = 20.sp, lineHeight = 26.sp)
        Text(reading.subtitle, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("${reading.category} · ${reading.minutes} dk", fontSize = 11.sp, color = Gold)
            Icon(Icons.Default.ArrowForward, contentDescription = "Oku", tint = Gold, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun DiscoverPage(
    pack: ContentPack, online: List<WebStory>, cacheDate: String, refreshing: Boolean, updateError: String,
    query: String, setQuery: (String) -> Unit, search: () -> Unit, searching: Boolean,
    searched: Boolean, searchError: String, searchResults: List<WebStory>,
    onRefresh: () -> Unit, onReading: (String) -> Unit, onWeb: (WebStory) -> Unit
) {
    var category by rememberSaveable { mutableStateOf("Hepsi") }
    val categories = listOf("Hepsi", "Edebiyat", "Bilim", "Tarih", "Felsefe", "Psikoloji", "Ekonomi", "Öykü")
    PageContent {
        Eyebrow("Kütüphane · keşif · merak")
        LabelTitle("Dünyaya başka bir gözle bak.", "Yazarlar, fikirler, ilginç gerçekler… Tek bir isim listesine bağlı değilsin.")
        SurfaceCard {
            Eyebrow("Her yazarı ve her konuyu ara")
            OutlinedTextField(value = query, onValueChange = setQuery,
                label = { Text("Yazar veya konu yaz") }, placeholder = { Text("Örn. Ursula K. Le Guin") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold,
                    unfocusedBorderColor = Line, focusedLabelColor = Gold))
            PrimaryButton(if (searching) "Aranıyor…" else "İnternette ara", search, enabled = !searching && query.isNotBlank())
            if (searchError.isNotBlank()) Text(searchError, color = Muted, fontSize = 12.sp)
            if (searched && !searching && searchResults.isEmpty() && searchError.isBlank())
                Text("Sonuç bulunamadı. Başka bir isim veya yazım deneyebilirsin.", color = Muted, fontSize = 12.sp)
            searchResults.forEach { item -> WebTile(item, onClick = { onWeb(item) }) }
            Text("İnternet sonuçları: Vikipedi. Kaynak ve lisans bilgisi içerikte görünür.", color = Muted, fontSize = 10.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            LabelTitle("Günün yeni keşifleri", "Son indirme: ${cacheDate.ifBlank { "Henüz yok" }}")
            TextButton(onClick = onRefresh, enabled = !refreshing) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
                Text(if (refreshing) "Yükleniyor" else "Yenile", color = Gold, fontSize = 12.sp)
            }
        }
        if (updateError.isNotBlank()) Text(updateError, color = Muted, fontSize = 12.sp)
        if (online.isEmpty()) Text("Bağlandığında yeni yazılar gelecek. Aşağıda çevrimdışı okumalar hazır.", color = Muted, fontSize = 13.sp)
        online.forEach { item -> WebTile(item, onClick = { onWeb(item) }) }
        LabelTitle("Kısa okumalar", "Yavaşça okuyabileceğin özgün yazılar")
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories.size) { i ->
                val item = categories[i]
                FilterChip(selected = category == item, onClick = { category = item },
                    label = { Text(item, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold,
                        selectedLabelColor = Navy, containerColor = Panel, labelColor = Muted),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (category == item) Gold else Line))
            }
        }
        pack.readings.filter { category == "Hepsi" || it.category == category }.forEach { reading ->
            ReadingTile(reading, onClick = { onReading(reading.id) })
        }
        LabelTitle("Bunu biliyor muydun?", "Kısa bilgiler, tek ekranda")
        pack.facts.forEach { fact ->
            SurfaceCard {
                Eyebrow(fact.category)
                Text(fact.title, color = Cream, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(fact.body, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun WebTile(story: WebStory, onClick: () -> Unit) {
    SurfaceCard(Modifier.clickable(onClick = onClick)) {
        Eyebrow(story.topic)
        Text(story.title, fontSize = 17.sp, lineHeight = 23.sp,
            fontWeight = FontWeight.SemiBold, color = Cream)
        Text(story.intro, color = Muted, fontSize = 12.sp, maxLines = 3,
            lineHeight = 19.sp, overflow = TextOverflow.Ellipsis)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Vikipedi · kaynaklı içerik", color = Gold, fontSize = 11.sp)
            Icon(Icons.Default.ChevronRight, contentDescription = "Aç", tint = Gold)
        }
    }
}

@Composable
private fun OnlineArticle(story: WebStory, onBack: () -> Unit, onOpen: (String) -> Unit) {
    PageContent {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Gold)
            Text("Keşfe dön", color = Gold) }
        Eyebrow("İnternetten keşif · ${story.topic}")
        Text(story.title, color = Cream, fontFamily = FontFamily.Serif, fontSize = 26.sp, lineHeight = 33.sp)
        Spacer(Modifier.height(3.dp))
        Text(story.intro, color = Cream, fontSize = 16.sp, lineHeight = 27.sp)
        SurfaceCard {
            Eyebrow("Kaynak ve kullanım")
            Text("Bu açıklama Türkçe Vikipedi'den alınmıştır. Metin Vikipedi katılımcılarına aittir; CC BY-SA lisansı kapsamında sunulur. Konu hakkında daha ayrıntılı bilgi için kaynak sayfasına gidebilirsin.",
                color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
            PrimaryButton("Kaynağın tamamını oku", onClick = { onOpen(story.link) }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ReadingPage(
    item: Reading, read: Boolean, saved: Boolean, onBack: () -> Unit, onRead: () -> Unit,
    onSave: () -> Unit, words: List<Word>
) {
    var selected by rememberSaveable(item.id) { mutableIntStateOf(-1) }
    var checked by rememberSaveable(item.id) { mutableStateOf(false) }
    PageContent {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Gold)
                Text("Kütüphaneye dön", color = Gold, fontSize = 12.sp)
            }
            IconButton(onClick = onSave) {
                Icon(if (saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = if (saved) "Kaydedildi" else "Kaydet", tint = Gold)
            }
        }
        Eyebrow("${item.category} · ${item.minutes} dakika")
        Text(item.title, color = Cream, fontFamily = FontFamily.Serif, fontSize = 27.sp, lineHeight = 34.sp)
        Text(item.subtitle, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
        HorizontalDivider(color = Line)
        item.paragraphs.forEach { p -> Text(p, color = Cream, fontSize = 16.sp, lineHeight = 28.sp,
            fontFamily = FontFamily.Serif) }
        if (words.isNotEmpty()) {
            SurfaceCard {
                Eyebrow("Bu okumadaki kelimeler")
                words.forEach { w ->
                    Text(w.word, fontWeight = FontWeight.Medium, color = Gold, fontSize = 15.sp)
                    Text(w.meaning, color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
        }
        SurfaceCard {
            Eyebrow("Bir dakikalık kontrol")
            Text(item.question, fontSize = 15.sp, color = Cream, fontWeight = FontWeight.SemiBold, lineHeight = 23.sp)
            item.options.forEachIndexed { index, option ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp)).clickable { if (!checked) selected = index }
                    .background(if (selected == index) PanelLight else Color.Transparent)
                    .padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selected == index, onClick = { if (!checked) selected = index },
                        enabled = !checked, colors = RadioButtonDefaults.colors(selectedColor = Gold))
                    Spacer(Modifier.width(6.dp))
                    Text(option, color = Cream, fontSize = 13.sp)
                }
            }
            PrimaryButton("Cevabımı kontrol et", onClick = { checked = true }, enabled = selected >= 0 && !checked)
            if (checked) {
                Text(if (selected == item.answer) "Doğru cevap." else "Bu kez olmadı. Birlikte öğrenelim.",
                    color = if (selected == item.answer) Green else Gold, fontWeight = FontWeight.SemiBold)
                Text(item.explanation, color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
            }
        }
        PrimaryButton(if (read) "Okundu · geri al" else "Okumayı tamamladım",
            onRead, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun WordsPage(store: MerakStore, words: List<Word>, onChange: () -> Unit) {
    var showAll by rememberSaveable { mutableStateOf(false) }
    var search by rememberSaveable { mutableStateOf("") }
    val offset = Math.floorMod(dayNumber() * 3, words.size.toLong()).toInt()
    val today = (0 until 3).map { words[(offset + it) % words.size] }
    val selectedWords = if (showAll) words.filter {
        it.word.contains(search, ignoreCase = true) || it.meaning.contains(search, ignoreCase = true)
    } else today
    PageContent {
        Eyebrow("Bir kelime, yeni bir düşünce")
        LabelTitle("Kelimeler", "Her gün üç kelime. Ezberlemek değil, gerçekten kullanmak önemli.")
        SurfaceCard {
            Text("${store.knownCount()} kelimeyi öğrendin", color = Cream, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text("Bir kelimeyi bir cümlede kullanabildiğinde işaretle.", color = Muted, fontSize = 12.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedSmall("Günün üç kelimesi", onClick = { showAll = false })
            OutlinedSmall("Tüm kelimeler", onClick = { showAll = true })
        }
        if (showAll) OutlinedTextField(value = search, onValueChange = { search = it },
            label = { Text("Kelime ara") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Line))
        selectedWords.forEach { item ->
            SurfaceCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Eyebrow(item.category)
                        Text(item.word, color = Cream, fontSize = 20.sp, fontFamily = FontFamily.Serif)
                    }
                    Icon(if (store.knowWord(item.id)) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = null, tint = if (store.knowWord(item.id)) Green else Muted,
                        modifier = Modifier.size(23.dp))
                }
                Text(item.meaning, color = Cream, fontSize = 14.sp, lineHeight = 22.sp)
                Text("Örnek: ${item.example}", color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
                if (item.alternative.isNotBlank()) Text(item.alternative, color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
                OutlinedSmall(if (store.knowWord(item.id)) "Öğrendim · geri al" else "Bunu öğrendim",
                    onClick = { store.toggleWord(item.id); onChange() })
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ProfilePage(store: MerakStore, onChange: () -> Unit) {
    var note by rememberSaveable { mutableStateOf(store.nightNote) }
    PageContent {
        Eyebrow("Burası senin alanın")
        LabelTitle("Kendine iyi davran.", "Her gün kusursuz olmak zorunda değilsin; küçük adımların devamlılığı önemli.")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("${store.readCount()}", "Okuma", Modifier.weight(1f))
            MetricCard("${store.knownCount()}", "Kelime", Modifier.weight(1f))
            MetricCard("${store.completionDays()}", "Gün", Modifier.weight(1f))
        }
        SurfaceCard {
            Eyebrow("Akşam için küçük bir fikir")
            Text("Yatmadan önce 10 dakika ekransız kalmayı dene.", color = Cream, fontSize = 15.sp, lineHeight = 22.sp)
            Text("Telefonu kenara koy, ışığı azalt. Yapamadığın gün kendini suçlama.", color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = store.bedtimePlan,
                    onCheckedChange = { store.bedtimePlan = it; onChange() },
                    colors = CheckboxDefaults.colors(checkedColor = Gold, checkmarkColor = Navy))
                Text("Bugün bunu deneyeceğim", color = Cream, fontSize = 13.sp)
            }
        }
        SurfaceCard {
            Eyebrow("Günün son cümlesi")
            Text("Bugün kendin için ne yaptın?", color = Cream, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            OutlinedTextField(value = note, onValueChange = { note = it },
                placeholder = { Text("Kendine bir not bırak…") }, minLines = 3, maxLines = 6,
                modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold, unfocusedBorderColor = Line))
            PrimaryButton("Notumu kaydet", onClick = { store.nightNote = note; onChange() })
        }
        SurfaceCard {
            Eyebrow("MERAK ilk sürüm")
            Text("Bu uygulama bilgilenmek, kelime dağarcığını genişletmek ve günlük iyi oluşunu desteklemek için tasarlandı. Profesyonel psikolojik destek veya tedavinin yerini tutmaz.",
                color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
            Text("Ruh hâlin, notların ve öğrenme geçmişin yalnızca bu cihazda saklanır. İnternete yalnızca yeni Vikipedi içerikleri almak için bağlanır.",
                color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun MetricCard(number: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(15.dp)).background(Panel).padding(13.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(number, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}
