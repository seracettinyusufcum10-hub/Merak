# All content is bundled offline and parsed with Android's built-in JSON APIs.
