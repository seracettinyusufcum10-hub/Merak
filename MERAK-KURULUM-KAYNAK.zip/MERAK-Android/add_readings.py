"""More original literary introductions, not copyrighted text or fabricated quotations."""
import json
from pathlib import Path
p=Path(__file__).parent/'app/src/main/assets/content.json'
data=json.loads(p.read_text(encoding='utf-8'))

new=[
("tolstoy","Edebiyat","Tolstoy: Doğru hayat diye bir şey var mı?","Anna Karenina ile insanın seçimlerine yakından bak.",4,[
"Bir insan, kendisi için doğru olan hayatı nasıl bulur? Toplumun beklentileriyle kendi istekleri birbirinden ayrıldığında ne yapar? Lev Tolstoy'un romanlarında büyük olaylar vardır; ama okurun aklında çoğu zaman küçücük bir bakış, bir susuş veya bir karar kalır.",
"Anna Karenina, yalnızca bir aşk hikâyesi değildir. Evlilik, aile, toplumsal saygınlık ve kişisel mutluluk gibi konuları farklı karakterlerin hayatlarından gösterir. Bir insanın iç dünyasıyla yaşadığı çevre arasında nasıl sıkışabildiğini sorgular.",
"Tolstoy'un bazı karakterleri ise büyük bir zaferin ya da yüksek bir konumun insanı otomatik olarak mutlu etmediğini keşfeder. Dışarıdan bakıldığında 'başarılı' görünen bir yaşamın içeriden nasıl hissedildiği bambaşka olabilir.",
"Buradaki soru basit fakat zor: Başkaları doğru bulduğu için mi bir şeyi istiyoruz, yoksa gerçekten bize anlamlı geldiği için mi? Bu sorunun kesin bir cevabı yok. Ama başkalarının beklentilerini fark etmek, kendi kararlarımızı daha bilinçli vermemizi sağlayabilir.",
"Bir gün kendine şunu sor: Bugün verdiğin kararlardan hangisi gerçekten senin seçimin?"],
"Anna Karenina hangi yazarın romanıdır?",["Lev Tolstoy","Anton Çehov","Fyodor Dostoyevski","Nikolay Gogol"],0,
"Anna Karenina'nın yazarı Lev Tolstoy'dur.",["ozsaygi","arayis","bilinc"]),
("woolf","Edebiyat","Virginia Woolf: Kendi odana ihtiyacın var mı?","Yaratıcılık ve özgürlük yalnızca yetenekten ibaret değil.",4,[
"Bir fikrin olduğunu düşün. Yazmak, çizmek, bir şey üretmek istiyorsun. Fakat hiç zamanın yok, odan kalabalık, herkes senden farklı şeyler bekliyor. Böyle bir durumda yetenek tek başına yeterli olur mu?",
"Virginia Woolf, Kendine Ait Bir Oda adlı denemesinde kadınların edebî üretim olanaklarını tartışırken maddi bağımsızlık ve özel alanın önemini vurgular. Anlatmak istediği sadece dört duvar değildir: Düşünmek için zaman, güvenlik ve özgürlük de gerekir.",
"Woolf'un romanlarında da düşünceler çoğu zaman düz bir çizgi halinde ilerlemez. İnsan zihni bir an eski bir anıya döner, sonra pencerenin önündeki ışığı fark eder. Bu nedenle onun eserleri okuyucuyu bazen yavaşlamaya davet eder.",
"Bugün yaratıcı bir şey yapmak için mükemmel şartlara sahip olman gerekmiyor. Ama kendine küçük bir alan açman önemli. Telefonu on dakika kenara bırakmak bile zihnin sürekli bölünmesini azaltabilir.",
"Şunu düşün: Sadece senin merakına ait bir on dakikan olsaydı, ne öğrenmek isterdin?"],
"Kendine Ait Bir Oda adlı eser kime aittir?",["Jane Austen","Virginia Woolf","Mary Shelley","Emily Brontë"],1,
"Kendine Ait Bir Oda, Virginia Woolf'un 1929'da yayımlanan denemesidir.",["ifade","irade","erisim"]),
("shakespeare","Edebiyat","Shakespeare: Bir soru neden yüzyıllarca yaşar?","Hamlet'in kararsızlığından gündelik hayatımıza uzanan bir yol.",4,[
"Bir karar vermen gerekiyor ama hangi seçimi yapsan bir şey kaybedecekmişsin gibi geliyor. Bir süre sonra sorun seçeneklerden çok, karar verememek oluyor. William Shakespeare'in Hamlet adlı trajedisinde bunun çok daha ağır bir biçimini görürüz.",
"Hamlet'in hayatı aile, iktidar, yas ve kuşku etrafında altüst olur. Bir yandan gerçeği öğrenmek ister, öte yandan bildiğini sandığı şeylerden emin olamaz. Onun iç konuşmaları, okura veya izleyiciye zihinle eylem arasındaki mesafeyi hissettirir.",
"Shakespeare'in sahneleri yalnızca krallar ve saraylar hakkında değildir. Kıskançlık, dostluk, korku, sevgi ve gurur gibi duygular bugün de tanıdıktır. Bir eser yüzyıllarca yaşadığında çoğu zaman sebep kostümleri değil, insanlarla kurduğu bağdır.",
"Bazen karar verebilmek için bütün soruların cevaplanmasını bekleriz. Oysa birçok gündelik durumda kesinlik diye bir şey yoktur. Önemli olan riskleri görebilmek ve sorumluluk alabilmektir.",
"Küçük bir deney: Uzun süredir ertelediğin bir kararı ve onu zorlaştıran tek soruyu yaz."],
"Hamlet hangi yazara aittir?",["Molière","William Shakespeare","Dante Alighieri","Victor Hugo"],1,
"Hamlet, William Shakespeare'in trajedisidir.",["sorgulama","kararlilik","celiski"]),
("shelley","Edebiyat","Mary Shelley: Canavar kim?","Frankenstein'ın gerçek sorusu göründüğünden derin.",4,[
"Birçok kişi Frankenstein denildiğinde boynunda metal parçaları olan bir canavar düşünür. Oysa Mary Shelley'nin romanında Frankenstein, yaratığın değil onu meydana getiren Victor Frankenstein'ın soyadıdır.",
"Genç bir bilim insanı yaşam oluşturmayı başarır ama ortaya çıkan varlığa karşı sorumluluğunu üstlenmekte zorlanır. Hikâyedeki asıl korku yalnızca yaratığın görüntüsü değil, onu yalnız bırakan insanların davranışlarıdır.",
"Shelley'nin romanı bilim, etik ve yalnızlık üzerine önemli sorular sorar. Bir şeyi yapabilecek gücümüzün olması, onu düşünmeden yapmamız gerektiği anlamına gelir mi? Ortaya çıkardığımız sonuçlardan ne ölçüde sorumluyuz?",
"Bu sorular bugün yapay zekâdan genetik araştırmalara kadar pek çok tartışmada yeniden karşımıza çıkar. Elbette yeni teknolojiler romanın olaylarıyla birebir aynı değildir; önemli olan sorumluluğun unutulmamasıdır.",
"Bir fikir üretirken önce 'Yapabilir miyim?' diye soruyorsan, yanına 'Yaparsam kime etkisi olur?' sorusunu da ekle."],
"Frankenstein romanındaki Victor Frankenstein kimdir?",["Yaratığı ortaya çıkaran bilim insanı","Bir deniz kaptanı","Romanı yazan şair","Orta Çağ kralı"],0,
"Victor Frankenstein, romanda canlı bir varlık meydana getiren bilim insanıdır.",["varsayim","muhakeme","sorumluluk"]),
("borges","Edebiyat","Borges: Sonsuz bir kütüphanede kaybolmak","Bilgi çok olduğunda gerçeğe ulaşmak kolaylaşır mı?",4,[
"Bütün kitapların bulunduğu bir kütüphane hayal et. Her cevap, her hikâye, her saçmalık orada olsun. İlk düşüncen mutluluk olabilir: Artık hiçbir şeyi aramak zorunda kalmayacağım. Ama hemen sonra başka bir sorun çıkar: Aradığım doğru kitabı nasıl bulacağım?",
"Arjantinli yazar Jorge Luis Borges'in Babil Kitaplığı adlı öyküsü, sınırsız bilgi fikrini insanı şaşırtan bir kurguya dönüştürür. Sayısız kitabın bulunması, anlamlı bir cevabı bulmayı garanti etmez.",
"İnternette de benzer bir durum yaşarız. Binlerce sonuç görmek bazen daha bilgili hissettirir. Fakat bir bilginin kaynağına, bağlamına ve doğruluğuna bakmadığımızda yalnızca daha fazla cümle görmüş oluruz.",
"Borges'in oyunbaz metinleri labirentler, aynalar ve sonsuzluk düşüncesiyle doludur. Ama onların ardında çok insani bir duygu bulunur: Bilmek istiyoruz ve bildiklerimizin yeterli olduğundan emin olamıyoruz.",
"Bugün merak ettiğin bir konuda tek bir güvenilir kaynak bul ve neden ona güvendiğini kendi kendine açıkla."],
"Babil Kitaplığı öyküsünün yazarı kimdir?",["Italo Calvino","Jorge Luis Borges","Umberto Eco","Julio Cortázar"],1,
"Babil Kitaplığı, Jorge Luis Borges'in öyküsüdür.",["baglam","kaynak","muhakeme"]),
("oguzatay","Edebiyat","Oğuz Atay: Herkes uyum sağlamak zorunda mı?","Tutunamayanlar'ın yabancı hissettiren dünyası.",4,[
"Bazen bir ortamda herkes kuralları biliyormuş gibi davranır ama sen sanki yanlış yere gelmiş gibi hissedersin. Oğuz Atay'ın eserlerindeki yabancılık duygusu, yalnızca tek başına kalmakla ilgili değildir; çevrendeki kalıplara uymakta zorlanmakla da ilgilidir.",
"Tutunamayanlar romanı, modern Türk edebiyatının dikkat çekici eserlerinden biridir. Dili, anlatım biçimi, mizahı ve iç konuşmalarıyla okuru alışılmış çizginin dışına çıkarır. Roman kolay bir ilk okuma olmayabilir; fakat taşıdığı sorular gündelik hayatta tanıdıktır.",
"Başarılı sayılmak için herkesin benzer bir yol izlemesi gerekiyormuş gibi konuşulur: Aynı saatte uyanmak, aynı işte çalışmak, aynı yaşta aynı şeyleri yapmak. Bu beklentiler insanın kendi ritmini görmesini zorlaştırabilir.",
"Farklı olmak otomatik olarak doğru olmak demek değildir. Ama yalnızca çevrenin alışkanlıkları yüzünden kendi düşüncelerini susturmak da iyi bir çözüm sayılmaz. Düşünmek için bazen kalabalığın sesini azaltmak gerekir.",
"Bugün kendine ait bir tercihi düşün. Onu gerçekten istediğin için mi yapıyorsun, yoksa herkes öyle yaptığı için mi?"],
"Tutunamayanlar romanının yazarı kimdir?",["Yusuf Atılgan","Oğuz Atay","Orhan Kemal","Ahmet Hamdi Tanpınar"],1,
"Tutunamayanlar'ın yazarı Oğuz Atay'dır.",["yabancilasma","onyargi","ifade"]),
("yasarkemal","Edebiyat","Yaşar Kemal: Bir hikâyenin toprağı olur mu?","İnce Memed ile insan, doğa ve adaletsizlik.",4,[
"Bir romanın geçtiği yeri gözünün önüne getirebildiğinde hikâye değişir. Sadece karakterleri değil, sıcaklığı, rüzgârı, toprağın kokusunu da hayal etmeye başlarsın. Yaşar Kemal'in anlatıları özellikle bu bakımdan güçlüdür.",
"İnce Memed, Çukurova'da geçen ve baskı, eşitsizlik, direniş gibi konularla ilgilenen bir romandır. Eserin merkezindeki kişi, yaşadığı çevrenin koşullarıyla mücadele eder. Yalnızca ne yaptığı değil, neden yaptığı da önemlidir.",
"Yaşar Kemal'in dili doğayı bir arka plan süsü gibi bırakmaz. Dağlar, ovalar, mevsimler anlatılan dünyanın parçasına dönüşür. Böylece karakterlerin aldığı kararları ve karşılaştıkları güçlükleri daha yakından hissederiz.",
"Bir olayın yalnızca sonucunu duymakla, onu yaşayan kişinin çevresini tanımak aynı şey değildir. Bu yüzden hikâyeler bazen kuru bir bilgiden daha uzun süre akılda kalır.",
"Bugün bulunduğun bir yeri beş kelimeyle tarif etmeyi dene. Belki senin hikâyenin başlangıcı da oradadır."],
"İnce Memed romanı ağırlıklı olarak hangi bölgede geçer?",["Çukurova","Trakya","Kapadokya","Doğu Karadeniz"],0,
"İnce Memed, Çukurova coğrafyasıyla yakından ilişkilidir.",["gozlem","ayrinti","ifade"]),
("sabahattinali","Edebiyat","Sabahattin Ali: Tanımadığımız insanı tanıyor sanmak","Kürk Mantolu Madonna ile önyargı üzerine düşün.",4,[
"Birini sessiz, sıradan ya da tuhaf bulup hakkında hemen karar verdiğin oldu mu? Bazen insanların en önemli hikâyeleri dışarıdan hiç görünmez. Sabahattin Ali'nin Kürk Mantolu Madonna romanı bu farkı hatırlatır.",
"Eserin merkezindeki Raif Efendi, çevresindeki birçok kişi tarafından silik bir insan gibi görülür. Oysa geçmişinde çok daha yoğun duygular, hayaller ve yaşantılar vardır. Okur onu tanıdıkça ilk izlenimlerin ne kadar eksik kalabildiğini fark eder.",
"Roman, sevgi ve yalnızlığın yanında bir insanı gerçekten anlamanın güçlüğünü de düşündürür. Karşımızdaki kişinin susması, anlatacak bir şeyi olmadığı anlamına gelmez.",
"Günlük hayatta hızlı karar vermek kolaydır. Sosyal medyada birkaç fotoğrafa, kısa bir yoruma veya tek bir davranışa bakıp birinin kişiliğine dair hüküm veririz. Oysa elimizde yalnızca küçük bir parça vardır.",
"Bugün tanıdığın biri hakkında hemen düşündüğün bir yargıyı fark etmeye çalış. Sonra kendine sor: Elimde ne kadar kanıt var?"],
"Kürk Mantolu Madonna romanındaki karakterlerden biri hangisidir?",["Raif Efendi","Gregor Samsa","Raskolnikov","Hamlet"],0,
"Raif Efendi, Kürk Mantolu Madonna'nın temel karakterlerinden biridir.",["onyargi","kanit","merhamet"]),
("montaigne","Felsefe","Montaigne: Kendi düşünceni sınamak","Deneme yazmak neden kendinle konuşmaya benzer?",3,[
"Bir konuda fikrini söylediğinde hemen kesin konuşmak zorunda mısın? Fransız düşünür Michel de Montaigne, Denemeler adlı eserinde insanın kendisini ve dünyayı gözlemlemesini, kendi düşüncelerini yoklamasını önemser.",
"Bir deneme, her zaman son sözün söylendiği bir metin değildir. Yazar bir sorudan yola çıkar, farklı ihtimallere bakar, kendi deneyimlerini tartar. Bazen sonuca ulaşmaktan çok düşünme yolu önemlidir.",
"Bu yaklaşım günlük tartışmalar için de kullanışlıdır. Bir görüş duyduğunda hemen kabul etmek veya reddetmek yerine neden öyle düşünüldüğünü sorabilirsin. Daha sonra kendi fikrinin nereden geldiğini düşünürsün.",
"Bir şeyi bilmiyorum demek, öğrenmenin başlangıcı olabilir. Belirsizliği kabul etmek, düşünmeyi bırakmak değil; daha iyi sorular hazırlamaktır.",
"Bugün sana çok kesin gelen bir düşünce seç. Karşıt görüşteki biri hangi kanıtı gösterebilir, bir dakika bunu düşün."],
"Denemeler adlı eser kime aittir?",["René Descartes","Michel de Montaigne","Voltaire","Jean-Jacques Rousseau"],1,
"Denemeler, Michel de Montaigne'in eseridir.",["varsayim","sorgulama","muhakeme"]),
("leguin","Edebiyat","Ursula K. Le Guin: Başka bir dünya, aynı sorular","Bilimkurgu yalnızca uzay gemisi değildir.",4,[
"Bir bilimkurgu kitabı düşündüğünde aklına uzay gemileri, robotlar veya uzak gezegenler gelebilir. Ursula K. Le Guin'in eserlerinde ise başka dünyalar, insan toplumunu farklı gözlerle düşünmemiz için bir fırsattır.",
"Mülksüzler romanı, birbirinden farklı toplumsal düzenlere sahip iki dünyanın insanlarını ve düşüncelerini anlatır. Özgürlük, mülkiyet, sorumluluk ve birlikte yaşama gibi sorular okurun önüne gelir. Roman tek bir kolay cevap dayatmaz.",
"Le Guin'in başka eserlerinde dil, kültür, cinsiyet ve güç ilişkileri de önemlidir. Yabancı bir gezegeni anlamaya çalışan kahraman, aslında kendi toplumunun neyi normal saydığını da fark etmeye başlar.",
"Başka bir yaşam biçimini hayal etmek, bugünkü hayatı daha iyi anlamamıza yardımcı olabilir. Bu nedenle iyi bilimkurgu bazen geleceği tahmin etmekten çok bugünü sorgulatır.",
"Şunu düşün: Herkesin alıştığı bir kuralı bir günlüğüne değiştirebilseydin, hangisini değiştirirdin?"],
"Mülksüzler romanının yazarı kimdir?",["Isaac Asimov","Ursula K. Le Guin","Arthur C. Clarke","Frank Herbert"],1,
"Mülksüzler romanını Ursula K. Le Guin yazmıştır.",["sorgulama","ozsaygi","varsayim"]),
("zweig","Edebiyat","Stefan Zweig: Bütün dünya tek bir odaya sığar mı?","Satranç, yalnızlık ve zihnin sınırları.",4,[
"Bir insanın günlerce neredeyse hiçbir uyaran olmadan kapalı kaldığını hayal et. Böyle bir ortamda zaman nasıl geçer? Zihin neye tutunur? Stefan Zweig'ın Satranç adlı uzun öyküsü, bu tür soruları gerilimli bir anlatıya dönüştürür.",
"Eserde satranç yalnızca bir oyun değildir. Karakterlerin zihinlerini, geçmişlerini ve baskı altında nasıl değişebildiklerini görmemize yardımcı olur. Tahtada yapılan hamlelerin arkasında çok daha büyük bir çatışma hissedilir.",
"Zweig'ın anlatıları genellikle uzun açıklamalardan çok duygusal gerilimleri ve insanın içinden geçenleri öne çıkarır. Bu nedenle kitap okumaya yeni başlayan biri için bazı eserleri daha ulaşılabilir gelebilir.",
"Yalnızlık, odaklanma ve düşüncelerle baş başa kalmak herkes için aynı şeyi ifade etmez. Kimi zaman sakinlik verir; kimi zaman ise insanın zihni kendine çok yüksek sesle konuşmaya başlar.",
"Bugün on dakika sessizce bir şeye odaklanmayı dene. Bu bir sayfa okumak da olabilir, kısa bir yürüyüş de."],
"Satranç adlı eserin yazarı kimdir?",["Franz Kafka","Stefan Zweig","Hermann Hesse","Arthur Schnitzler"],1,
"Satranç, Stefan Zweig'ın eseridir.",["bilinc","gozlem","irade"]),
("saramago","Edebiyat","Saramago: Herkes aynı anda kör olsa?","Körlük romanının topluma yönelttiği zor soru.",4,[
"Bir sabah şehirde insanlar beklenmedik biçimde görme yetilerini kaybetmeye başlıyor. José Saramago'nun Körlük romanındaki bu fikir bir felaket hikâyesi yaratır. Ama yazarın ilgisi yalnızca ne olduğunda değildir; insanların birbirine nasıl davrandığında da gizlidir.",
"Düzen bozulduğunda nezaket, dayanışma ve güç ilişkileri daha görünür hâle gelir. İnsanların değerlerini yalnızca rahat günlerde değil, zor koşullarda da nasıl yaşadıkları sorgulanır.",
"Romanı okurken akla şu soru gelebilir: Görmek sadece gözlerle mi ilgilidir? Birinin ihtiyacını fark etmek, haksızlığı anlamak veya etrafındaki insanları dikkate almak da başka tür bir görme sayılabilir.",
"Bir toplumun kuralları, herkesin birbirini her zaman anlayacağı anlamına gelmez. Ama küçük dayanışma hareketlerinin büyük bir etkisi olabilir. Saramago'nun sarsıcı anlatısı, kolay cevaplardan çok tartışılacak sorular bırakır.",
"Bugün çevrendeki birinin fark edilmeyen küçük bir ihtiyacını görmeye çalış. Yardım etmek bazen çok büyük bir şey olmak zorunda değil."],
"Körlük romanının yazarı hangisidir?",["José Saramago","Albert Camus","Italo Calvino","Umberto Eco"],0,
"Körlük, José Saramago'nun romanıdır.",["merhamet","onyargi","sorgulama"]),
("austen","Edebiyat","Jane Austen: İlk izlenim neden yanıltır?","Gurur ve Önyargı'nın bugün bile tanıdık gelen soruları.",4,[
"Bir insanı ilk gördüğünde onun hakkında birkaç saniyede fikir edinirsin. Bazen bu işe yarar, bazen de ciddi biçimde yanılırsın. Jane Austen'in Gurur ve Önyargı romanı, tam da bu hızlı yargıları ve onları değiştiren deneyimleri konu alır.",
"Elizabeth Bennet ve Fitzwilliam Darcy arasındaki ilişki, karakterlerin gurur ve önyargıları nedeniyle karmaşıklaşır. Roman yalnızca romantik bir hikâye değildir; sınıf, aile, evlilik ve toplumsal beklentiler hakkında da keskin gözlemler içerir.",
"Austen'in güçlü yanlarından biri, insanların kendilerini ne kadar iyi tanıdıklarını zannederken yanılabileceklerini mizahla gösterebilmesidir. Okur bir karakter hakkında fikir oluşturur, sonra yeni bir olayla bu fikrini sorgular.",
"Bugün birini sadece tek bir davranışıyla tanımlamamaya çalış. O davranışın başka bir açıklaması olabilir mi? İnsanları anlamak kesin etiketler koymaktan biraz daha fazla zaman isteyebilir.",
"Belki de birini tanımaya başlamanın en iyi yolu, ilk kararından biraz şüphe etmektir."],
"Gurur ve Önyargı romanını kim yazmıştır?",["Emily Brontë","Jane Austen","Virginia Woolf","George Eliot"],1,
"Gurur ve Önyargı, Jane Austen'in romanıdır.",["onyargi","gozlem","celiski"]),
("achebe","Edebiyat","Chinua Achebe: Bir hikâyeyi kim anlatır?","Parçalanma ile tek bakış açısının ötesine bak.",4,[
"Bir ülke veya toplum hakkında yalnızca dışarıdan gelen hikâyeleri dinlediğinde neler eksik kalır? Nijeryalı yazar Chinua Achebe, Parçalanma romanıyla Afrika toplumlarının yaşamlarını ve sömürgeciliğin etkilerini içeriden anlatan önemli bir ses olmuştur.",
"Romanın merkezindeki Okonkwo, yaşadığı topluluğun gelenekleri, beklentileri ve değişen koşulları arasında var olmaya çalışır. Karakter kusursuz değildir; kimi zaman onun seçimlerine katılmak zordur. İşte tam da bu yüzden hikâye tek boyutlu bir anlatı olmaktan çıkar.",
"Bir toplumun hikâyesini tek bir kişinin, tek bir fotoğrafın veya tek bir haberin tamamıyla anlatması mümkün değildir. Kültürü, tarihsel koşulları ve bireylerin farklı deneyimlerini tanımak gerekir.",
"Bu durum yalnızca uzak coğrafyalara ait değildir. Kendi şehrindeki bir mahalle hakkında bile dışarıdan bakınca eksik bilgiye sahip olabilirsin. Merak etmek, kesin yargı vermekten önce gelmelidir.",
"Bugün başka bir yer hakkında duyduğun tek bir genellemeyi sorgula. Gerçekte kaç farklı hikâye olabilir?"],
"Parçalanma romanının yazarı kimdir?",["Chinua Achebe","Ngũgĩ wa Thiong'o","Wole Soyinka","Ben Okri"],0,
"Parçalanma, Chinua Achebe'nin romanıdır.",["baglam","onyargi","gozlem"]),
("halideedib","Edebiyat","Halide Edib: Tarih yalnızca tarihlerden mi ibaret?","Ateşten Gömlek, insanların yaşadıklarıyla tarihi birleştirir.",4,[
"Tarih dersinde olayların tarihlerini öğrenebiliriz: hangi savaş ne zaman başladı, kim nerede görev yaptı? Ama bu olayları yaşayan insanların korkularını, umutlarını ve kayıplarını anlamak için farklı bir pencere gerekir.",
"Halide Edib Adıvar'ın Ateşten Gömlek romanı, Millî Mücadele dönemini bireylerin yaşantıları ve duyguları üzerinden anlatır. Edebiyat tarih kitabının yerine geçmez ama tarihsel atmosferi başka bir açıdan düşündürebilir.",
"Bir romandaki kişi kurmaca olabilir; yine de onun yaşadığı çatışmalar, gerçek dönemlerin zorluklarını anlamak için sorular doğurur. Burada önemli olan edebî anlatıyla tarihsel kanıtı birbirine karıştırmamaktır.",
"Bu yüzden bir olay hakkında bilgi edinirken hem güvenilir tarih kaynaklarına hem de dönemin insanlarına ait mektuplara, anılara ve edebî eserlere farklı amaçlarla bakabiliriz.",
"Bir tarih konusu seçtiğinde iki soru sor: Ne oldu? Bunu yaşayan bir insan nasıl hissetmiş olabilir?"],
"Ateşten Gömlek romanını kim yazmıştır?",["Yakup Kadri Karaosmanoğlu","Halide Edib Adıvar","Reşat Nuri Güntekin","Peyami Safa"],1,
"Ateşten Gömlek, Halide Edib Adıvar'ın romanıdır.",["kanit","baglam","miras"]),
("nazimhikmet","Edebiyat","Nâzım Hikmet: Şiir yalnızca kafiyeden mi ibaret?","Bir düşüncenin ritmi, kelimelerin anlamını değiştirebilir.",3,[
"Şiir denildiğinde yalnızca uyaklı dizeler düşünüyorsan bazı metinler seni şaşırtabilir. Nâzım Hikmet, modern Türk şiirinde serbest nazmın gelişiminde büyük rol oynamış şairlerden biridir.",
"Şiirin gücü bazen tek bir görüntüde, bazen kelimelerin ritminde, bazen de cümlelerin beklenmedik biçimde kırılmasında ortaya çıkar. Bir şiiri anlamak için her kelimenin sözlük karşılığını tek tek bilmek yeterli olmayabilir.",
"Şiir kimi zaman şehirleri, insanları, özlemi, umutları ve tarihsel olayları bir arada taşır. Aynı dizeleri farklı zamanlarda okuduğumuzda başka duygular uyandırması da bundandır.",
"Kelime hazneni geliştirmek için şiirden yararlanabilirsin. Kısa bir metinden ilgini çeken tek bir kelime seç ve kendi cümlende kullan. Bunu yaparken başkasının tarzını taklit etmek zorunda değilsin.",
"Bugün sık kullandığın bir kelimenin yerine daha tam ne demek istediğini anlatan başka bir sözcük bulabilir misin?"],
"Nâzım Hikmet'in Türk şiirinde geliştirilmesine katkı sağladığı biçim hangisidir?",["Serbest nazım","Mesnevi","Gazel","Mani"],0,
"Nâzım Hikmet, Türk şiirinde serbest nazmın önde gelen isimlerindendir.",["ifade","anlam","ayrinti"]),
("calvino","Edebiyat","Italo Calvino: Bir şehir hafızada nasıl yaşar?","Görünmez Kentler ile hayal kurmanın farklı yolları.",4,[
"Hiç görmediğin bir şehir hakkında yüzlerce ayrıntı düşünebilirsin. Sokakları nasıl, insanlar hangi seslerle uyanıyor, geceleri binaların ışıkları nasıl? Italo Calvino'nun Görünmez Kentler kitabı, şehirlere alışılmış bir seyahat rehberi gibi bakmaz.",
"Kitapta kurgusal kentler aracılığıyla bellek, arzu, zaman ve insanların yaşadıkları yerlere yüklediği anlamlar üzerinde düşünülür. Bir kent fiziksel binalardan ibaret değildir; ona dair hatıralar da şehri oluşturur.",
"Calvino okurun zihninde büyük bir dünya kurmak için her şeyi uzun uzun açıklamak zorunda olmadığını gösterir. Bazen kısa bir tasvir, sayfalarca bilginin veremediği bir duygu uyandırır.",
"Kendi yaşadığın yerde de buna benzeyen bir şey olabilir. Başkaları için sıradan bir durak, senin için önemli bir anının merkezi olabilir. Aynı sokak, farklı kişiler için farklı şehirlere dönüşür.",
"Bugün gördüğün bir yeri, adını hiç söylemeden üç cümleyle anlatmaya çalış. Bakalım başka biri gözünde canlandırabilecek mi?"],
"Görünmez Kentler kitabının yazarı kimdir?",["Italo Calvino","Jorge Luis Borges","Umberto Eco","Dino Buzzati"],0,
"Görünmez Kentler, Italo Calvino'nun eseridir.",["hafiza","anlam","ayrinti"])
]
for id,category,title,subtitle,minutes,paragraphs,question,opts,answer,explanation,words in new:
  words=[w for w in words if w in {item['id'] for item in data['words']}]
  if not any(a['id']==id for a in data['readings']):
      data['readings'].append(dict(id=id,category=category,title=title,subtitle=subtitle,minutes=minutes,paragraphs=paragraphs,question=question,options=opts,answer=answer,explanation=explanation,wordIds=words))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2), encoding='utf-8')
print('Readings:',len(data['readings']),'words:',len(data['words']),'facts:',len(data['facts']))
